package com.vsarode.main;


import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.dropbox.core.DbxException;
import com.vsarode.controller.BucketListHolder;
import com.vsarode.controller.ConfigureController;
import com.vsarode.controller.DownloadController;
import com.vsarode.controller.GuiHelperController;
import com.vsarode.controller.UploadController;
import com.vsarode.gui.ConfigureFormEvent;
import com.vsarode.gui.ConfigureFormListener;
import com.vsarode.gui.ConfigurePanel;
import com.vsarode.gui.DownloadFormEvent;
import com.vsarode.gui.DownloadFormListener;
import com.vsarode.gui.DownloadPanel;
import com.vsarode.gui.GuiHelper;
import com.vsarode.gui.ProgressPanel;
import com.vsarode.gui.ProgressUpdater;
import com.vsarode.gui.UploadFormEvent;
import com.vsarode.gui.UploadFormListener;
import com.vsarode.gui.UploadPanel;
import com.vsarode.model.BucketConfigurations;

public class MainApplication extends JFrame {

	
	private JPanel MainPanel;
	private JTabbedPane tabbedPanel; 
	private UploadPanel uploadPanel;
	private DownloadPanel downloadPanel;
	private ConfigurePanel configurePanel;
	private ProgressPanel progressPanel;
	private ProgressUpdater progressUpdater;
	
	public MainApplication() {
		
		this.setTitle("Secure Cloud Data Distribution Application");
		this.setMinimumSize(new Dimension(480, 420));
		
		this.setSize(600,400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		this.setLayout(new BorderLayout());
		
		MainPanel = new JPanel();
		MainPanel.setLayout(new BorderLayout());
		
		this.tabbedPanel = new JTabbedPane();
		uploadPanel = new UploadPanel();
		downloadPanel = new DownloadPanel();
		configurePanel = new ConfigurePanel();
		progressPanel = new ProgressPanel();

		tabbedPanel.addTab("Shuffle & Upload ", uploadPanel);
		tabbedPanel.addTab("Download & Merge", downloadPanel);
		tabbedPanel.addTab("Settings", configurePanel);		
		this.progressUpdater = new ProgressUpdater(this.progressPanel);
		
		this.getSelectedPanel();
		
		MainPanel.add(this.tabbedPanel, BorderLayout.NORTH);
		MainPanel.add(this.progressPanel, BorderLayout.SOUTH);
		
		this.add(MainPanel,BorderLayout.CENTER);
		
		
//		this.add(tabbedPanel,BorderLayout.NORTH);
//		this.add(progressPanel,BorderLayout.SOUTH);
		
		uploadPanel.setProgressUpdater(progressUpdater);
		downloadPanel.setProgressUpdater(progressUpdater);
		configurePanel.setProgressUpdater(progressUpdater);
		
		/**
		 * SETTING FORM LISTENER FOR THE UPLOAD PANEL TO HADLE THE EVENTS..
		 */
		uploadPanel.setFormListener(new UploadFormListener() {
			
			public void uploadFormEventOccured(UploadFormEvent uploadEvent) {
				
				UploadController uploadController= null;

				if(!GuiHelperController.checkDbxKey()){
					try {
						Thread.sleep(2500);
						String NewDbxKey = GuiHelper.getNewDbxKey();					
						uploadController = new UploadController(uploadEvent,NewDbxKey);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}else{
					uploadController = new UploadController(uploadEvent);
				}
				uploadController.startUploadingFiles();
			}
		});
		
		
		/**
		 * SETTING FORM LISTENER FOR THE DOWNLOAD PANEL TO HADLE THE EVENTS..
		 */
		downloadPanel.setDownloadFormListener(new DownloadFormListener() {
			
			public void downloadFormEventOccured(DownloadFormEvent downloadEvent) {
				DownloadController downloadController = null;

				if(!GuiHelperController.checkDbxKey()){
					try {
						Thread.sleep(2500);
						String NewDbxKey = GuiHelper.getNewDbxKey();					
						downloadController = new DownloadController(downloadEvent,NewDbxKey);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}else{
					downloadController = new DownloadController(downloadEvent);
				}
				downloadController.startDownloadingProcess();
			}
		});
		

		/**
		 * SETTING FORM LISTENER FOR THE CONFIGURE PANEL TO HADLE THE EVENTS..
		 */
		configurePanel.setConfigureFormListener(new ConfigureFormListener() {

			@Override
			public void ConfigureFormEventOccured(
					ConfigureFormEvent configureEvent) {
				
				ConfigureController configureController = new ConfigureController(configureEvent);
				configureController.SaveConfiguration();
			}
		});
				
		this.pack();
		 try {
			UIManager.setLookAndFeel(
			            UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}				
		setVisible(true);
		this.checkBucketConfiguration();
				
	}
	
	
	/**
	 * BUCKET CONFIG CHECK.
	 */
	public void checkBucketConfiguration(){
		
		if(!BucketConfigurations.isBucketConfigured()){
			int delay = 800; //milliseconds
			  ActionListener taskPerformer = new ActionListener() {
			      public void actionPerformed(ActionEvent evt) {
			    	  
			    	  new Thread(new Runnable() {
						
						@Override
						public void run() {
							JOptionPane msgBox = new JOptionPane();
							String message = "Buckets are not configured. Please configure buckets before you proceed.";
							
							if(msgBox.showConfirmDialog(null, message,"Warning",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE) == JOptionPane.OK_OPTION){
								tabbedPanel.setSelectedComponent(configurePanel);				
							}
						}
					}).start();
			      }
			  };
			  Timer myTimer = new Timer(delay, taskPerformer);
			  myTimer.setRepeats(false);
			  myTimer.start();
		}
	}
	
	
	public void getSelectedPanel(){
		this.tabbedPanel.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
			//	System.out.println("Selected panel index is : "+tabbedPanel.getSelectedIndex());
				new Thread(new Runnable() {
					
					@Override
					public void run() {
							if(tabbedPanel.getSelectedIndex() == 1){
								if(!GuiHelperController.checkDbxKey()){
									try {
										Thread.sleep(2500);
										String NewDbxKey = GuiHelper.getNewDbxKey();
										GuiHelperController.setNewDbxKey(NewDbxKey);
										
										BucketListHolder listHolderObj = GuiHelperController.getFilesListObject();
										downloadPanel.setDownloadFilesOptions(
																				listHolderObj.getFileSet(), 
																				listHolderObj.getFileList()
																			  );
									} catch (InterruptedException e1) {
										e1.printStackTrace();
									}
								}else{
									BucketListHolder listHolderObj = GuiHelperController.getFilesListObject();
									downloadPanel.setDownloadFilesOptions(
																			listHolderObj.getFileSet(),
																			listHolderObj.getFileList()
																		  );
								}							
							}
					}
				}).start();
				
			}
		});
	}
	
	
	
	public void checkKeyValidation(){
		int delay = 1500; //milliseconds
		  ActionListener taskPerformer = new ActionListener() {
		      public void actionPerformed(ActionEvent evt) {
		    	  
		    	  new Thread(new Runnable() {
					
					@Override
					public void run() {
						if(Desktop.isDesktopSupported()){
							try {
								Desktop.getDesktop().browse(new URI(GuiHelper.getDBXKeyLink()));
							} catch (IOException | URISyntaxException e) {
								e.printStackTrace();
							} catch (DbxException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();
		      }
		  };
		  Timer myTimer = new Timer(delay, taskPerformer);
		  myTimer.setRepeats(false);
		  myTimer.start();
	}
	
	
	
	/**
	 * MAIN FUNCTION 
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			public void run() {
				MainApplication panel = new MainApplication();
			}
		});
	}
}
