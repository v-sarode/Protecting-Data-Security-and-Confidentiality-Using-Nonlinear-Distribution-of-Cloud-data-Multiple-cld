package com.vsarode.gui;

public class ConfigureFormValidation {
	String Message ;
	String bucket1,bucket2,bucket3,bucket4,dbxkey;
	CloudServicesOptions b1cloud,b2cloud,b3cloud,b4cloud;
	
	public ConfigureFormValidation(	String bucket1,
									String bucket2,
									String bucket3,
									String bucket4,
									String dbxkey,
									CloudServicesOptions b1cloud,
									CloudServicesOptions b2cloud,
									CloudServicesOptions b3cloud,
									CloudServicesOptions b4cloud
									) {
		this.bucket1 = bucket1;
		this.bucket2 = bucket2;
		this.bucket3 =bucket3;
		this.bucket4 = bucket4;
		this.dbxkey = dbxkey;
		this.b1cloud = b1cloud;
		this.b2cloud = b2cloud;
		this.b3cloud = b3cloud;
		this.b4cloud = b4cloud;
		
	}

	
	public boolean isValid(){
		boolean test1,test2,test3,test4,test5 ;
		test1=test2=test3=test4=test5=true;
		
		String emptyParameters = "";
		String separator = " ,";
		
		if(this.bucket1.isEmpty() || this.b1cloud.getCloudName().isEmpty()){
			emptyParameters += "Select-Bucket1-Setting"+separator;
			test1= false;
		}
		
		if(this.bucket2.isEmpty() || this.b2cloud.getCloudName().isEmpty()){
			emptyParameters += "Select-Bucket2-Setting"+separator;
			test2= false;
		}

		if(this.bucket3.isEmpty() || this.b3cloud.getCloudName().isEmpty()){
			emptyParameters += "Select-Bucket3-Setting"+separator;
			test3= false;
		}

		if(this.bucket4.isEmpty() || this.b4cloud.getCloudName().isEmpty()){
			emptyParameters += "Select-Bucket4-Setting"+separator;
			test4= false;
		}
		

		if(this.dbxkey.isEmpty()){
			emptyParameters += "Provide-dbxKey-Setting"+separator;
			test5= false;
		}
		
		this.Message = "Please Fill "+emptyParameters;
		this.Message = this.Message.substring(0, this.Message.length()-1);
		return (test1&test2&test3&test4&test5);
	}
	
	
	public String getMessage(){
		return this.Message.trim();
	}
	
}
