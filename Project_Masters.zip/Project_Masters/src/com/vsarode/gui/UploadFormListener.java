package com.vsarode.gui;

import java.util.EventListener;

public interface UploadFormListener extends EventListener {
	public void uploadFormEventOccured(UploadFormEvent e);
}
