package com.vsarode.gui;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Set;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DownloadPanel extends JPanel {

	private JLabel selectFileLabel;
	private JLabel selectShuffleBytesLabel;
	private JLabel outputFilePathLabel;	
	private JTextField outputFilePathField;
	
	private JButton downloadButton;
	private JButton cancelButton;
	private JButton browseButton;
	
	private JComboBox shuffleBytes;

	
	private JComboBox selectFilecombobox;
	private DownloadFormListener downloadFormListener;
	private GridBagConstraints gc;
	private ProgressUpdater progressUpdater;
	private List<? extends Object> bucketFileList;
	private Panels PANEL;
	
	public DownloadPanel() {
		initializeComponets();

		this.setBorder(GuiHelper.applyBorder(PANEL.DOWNLOAD.toString()));
		this.setLayout(new GridBagLayout());
		this.addComponents();
		
		this.downloadButtonClicked();
		
		this.browseButtonClicked();
		cancelButton.addActionListener(new CancelAction("Download Panel"));		
	}
	

	/**
	 * BROWSE BUTTON CLICK
	 */
	private void browseButtonClicked() {
		new Thread(new Runnable() {							
			@Override
			public void run() {
				browseButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {				
						JFileChooser chooser = new JFileChooser(); 
					    chooser.setCurrentDirectory(new java.io.File("."));
					    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					    chooser.setAcceptAllFileFilterUsed(false);
					    
					    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) { 
							outputFilePathField.setText(chooser.getSelectedFile().getPath());
					    }else {
					    	ShowMessageBox.showMessage("You Never Selected Output Directory");
					    }				
			
					}
				});
			}
		}).start(); 			
	}





	/**
	 * Initialize components for download panel..
	 */
	private void initializeComponets() {
		this.selectFileLabel  = new JLabel("select File:");
		this.selectShuffleBytesLabel = new JLabel("Select Shuffle Bytes:");
		
		this.outputFilePathField = new JTextField();
		this.outputFilePathField.setEditable(false);
		this.outputFilePathField.setPreferredSize(new Dimension(190, 22));

		this.outputFilePathLabel = new JLabel("Output File Location:");
		this.downloadButton = new JButton("Download");
		this.cancelButton = new JButton("Cancel");
		this.browseButton = new JButton("Browse");
		
		this.selectFilecombobox = new JComboBox();
		
		this.selectFilecombobox.setPreferredSize(new Dimension(200, 25));
		
		this.shuffleBytes = new JComboBox();
		
		this.shuffleBytes.setModel(GuiHelper.getShuffleBytesList());
		
		this.shuffleBytes.setPreferredSize(new Dimension(200, 25));
		
		//setting current directory default for downloading
		String currentDirectory = System.getProperty("user.dir");
		this.outputFilePathField.setText(currentDirectory);
		gc = new GridBagConstraints();
	}


	/**
	 * add components to the download panel
	 */
	private void addComponents() {
		gc.gridy = 0;

		// FIRST ROW..		
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(selectFileLabel, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.selectFilecombobox, gc);
		
		// SECOND ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;		
		this.add(selectShuffleBytesLabel, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;		
		this.add(this.shuffleBytes, gc);
		

		
		// THORD ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;		
		this.add(this.outputFilePathLabel, gc);
		
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.outputFilePathField, gc);		

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.browseButton, gc);		

		
		// FOURTH ROW..	
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 2; 

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.downloadButton, gc);		

		gc.gridx++;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.cancelButton, gc);		
	}

	/**
	 * DOWNLOAD BUTTON CLICK
	 */
	private void downloadButtonClicked() {
		downloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						String outputDirectory = outputFilePathField.getText();
						String fileToBeDownloaded = (String) selectFilecombobox.getSelectedItem();
						ShuffleBytes selectedBytes = (ShuffleBytes)shuffleBytes.getSelectedItem();
						
						progressUpdater.updateProgress("Validating Download Parameters..",PANEL.DOWNLOAD.toString());
						DownloadFormValidation validationObject = new DownloadFormValidation(outputDirectory, selectedBytes, fileToBeDownloaded);
						
						if(validationObject.isValid()){
						
							DownloadFormEvent downloadEvent = new DownloadFormEvent(	this,
																						outputDirectory,
																						selectedBytes,
																						fileToBeDownloaded,
																						bucketFileList,
																						progressUpdater
																					);
							
							if(downloadFormListener!= null){
								downloadFormListener.downloadFormEventOccured(downloadEvent);
							}
						}else{
							ShowMessageBox.showMessage(validationObject.getMessage());
						}
					}
				}).start();
			}
		});
	}


	/**
	 * EVENT LISTENER SETUP FOR THE EVENT HANDLING INTO THE JFRAME CLASS
	 * @param downloadFormListener
	 */
	public void setDownloadFormListener(DownloadFormListener downloadFormListener){
		this.downloadFormListener = downloadFormListener;
	}

	
	/**
	 * function to handle the update status in status bar
	 * @param progressUpdater
	 */
	public void setProgressUpdater(ProgressUpdater progressUpdater){
		this.progressUpdater = progressUpdater;
	}
	
	/**
	 * function to get download file list into dropbox from clouds..
	 * @param options set of string values with the filenames in the buckets 
	 * @param bucketFileList
	 */
	public void setDownloadFilesOptions(Set<String> options, List<? extends Object> bucketFileList){
		DefaultComboBoxModel<String> downloadFilesOptions = new DefaultComboBoxModel<String>();
		for (String string : options) {
			downloadFilesOptions.addElement(string);
		}
		this.bucketFileList = bucketFileList;
		this.selectFilecombobox.setModel(downloadFilesOptions);
	}
	
	/**
	 * function to get files list from the cloud bucket.
	 * @param options set of strings from the bucket..
	 */
	public void setDownloadFilesOptions(Set<String> options){
		DefaultComboBoxModel<String> downloadFilesOptions = new DefaultComboBoxModel<String>();
		for (String string : options) {
			downloadFilesOptions.addElement(string);
		}
		this.bucketFileList = bucketFileList;

	}
	
}
