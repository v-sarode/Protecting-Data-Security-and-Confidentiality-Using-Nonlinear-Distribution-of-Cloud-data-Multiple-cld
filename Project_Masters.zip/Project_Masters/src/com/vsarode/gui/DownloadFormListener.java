package com.vsarode.gui;

public interface DownloadFormListener {
	public void downloadFormEventOccured(DownloadFormEvent e);
}
