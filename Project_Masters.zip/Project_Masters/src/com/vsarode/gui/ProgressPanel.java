package com.vsarode.gui;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class ProgressPanel extends JPanel{
	
	private JTextArea textArea;
	private JScrollPane scrollPane;
	public ProgressPanel() {
		this.applyBorder();
		this.initializeComponents();
		
		this.setLayout(new BorderLayout());
		this.add(this.scrollPane, BorderLayout.CENTER);
	}
	
	/**
	 * Initialize components for the panel 
	 */
	public void initializeComponents(){
		this.textArea = new JTextArea(8,8);
		textArea.setEditable(false);
		Font f = new Font(Font.SANS_SERIF, Font.PLAIN, 10);
		this.textArea.setFont(f);
		this.scrollPane = new  JScrollPane(this.textArea);
		

		this.scrollPane .setHorizontalScrollBarPolicy(
		        JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		this.scrollPane .setVerticalScrollBarPolicy(
		        JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	}
	
	
	/**
	 * function to apply border 
	 */
	public void applyBorder(){
		Border outsideBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		Border insideBorder = BorderFactory.createTitledBorder("Status Section");
		this.setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));		
	}
	
	/**
	 * function to update the status 
	 * @param Message String message value to update on the status panel
	 */
	public void updateStatus(String Message){
		this.textArea.append(Message);
	}
	

}
