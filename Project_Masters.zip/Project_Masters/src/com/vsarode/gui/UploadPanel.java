package com.vsarode.gui;



import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.DateFormat;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class UploadPanel extends JPanel {
	
	private JLabel selectFileLabel;
	private JLabel selectShuffleBytesLabel;
	private JLabel CloudsSelectionLabel;

	private JTextField filePathField;
	
	
	private JButton uploadButton;
	private JButton cancelButton;
	private JButton browseButton;
	
	private JComboBox shuffleBytes;
//	private DefaultComboBoxModel<ShuffleBytes> shuffleBytesValues;
	
	private JCheckBox bucket1;
	private JCheckBox bucket2;
	private JCheckBox bucket3;
	private JCheckBox bucket4;
	
	
	private GridBagConstraints gc;
	
	private UploadFormListener uploadFormListner;
	private UploadFormBucketEventHandler bucketEventHandler;
	private ProgressUpdater progressUpdater;
	private Panels PANELNAME ;
	
	private File TargetUploadFile;
	private String SelectedFileName;
	private String SelectedFileAbsolutePath;
	
	
	
	/**
	 * CONSTRUCTOR
	 */
	public UploadPanel(){
		
		initializeComponets();
		this.setBorder(GuiHelper.applyBorder(PANELNAME.UPLOAD.toString()));
		this.setLayout(new GridBagLayout());
		this.addComponents();
		
		this.UploadButtonClick();
		
		this.browseButtonClicked();
		cancelButton.addActionListener(new CancelAction("Upload Panel"));
		
	}
	
	public void initializeComponets(){
		this.selectFileLabel = new JLabel("File:");
		this.selectShuffleBytesLabel = new JLabel("Shuffle Bytes:");
		this.CloudsSelectionLabel = new JLabel("Cloud Services:");
//		this.Bucket1Label = new JLabel("cloud 1");
//		this.Bucket2Label = new JLabel("cloud 2");
//		this.Bucket3Label = new JLabel("cloud 3");
//		this.Bucket4Label = new JLabel("cloud 4");
		
		this.bucket1 = new JCheckBox("Bucket_1");
		this.bucket2 = new JCheckBox("Bucket_2");
		this.bucket3 = new JCheckBox("Bucket_3");
		this.bucket4 = new JCheckBox("Bucket_4");
		
		this.bucket1.setActionCommand("Bucket_1");
		this.bucket2.setActionCommand("Bucket_2");
		this.bucket3.setActionCommand("Bucket_3");
		this.bucket4.setActionCommand("Bucket_4");
		
		bucketEventHandler = new UploadFormBucketEventHandler();
		
		this.bucket1.addItemListener(bucketEventHandler); 
		this.bucket2.addItemListener(bucketEventHandler); 
		this.bucket3.addItemListener(bucketEventHandler); 
		this.bucket4.addItemListener(bucketEventHandler); 
		
		
		
		this.filePathField = new JTextField();
	//	this.filePathField.setEditable(false);
		this.filePathField.setPreferredSize(new Dimension(200, 25));
		
		
		this.uploadButton = new JButton("Upload");
		this.cancelButton = new JButton("Cancel");
		this.browseButton = new JButton("Browse");
		shuffleBytes = new JComboBox();
		shuffleBytes.setPreferredSize(new Dimension(200, 22));
		
//		shuffleBytesValues = new DefaultComboBoxModel<ShuffleBytes>();
//		final int BASE = 2;
//		for(int i = 2; i < 11;i++){
//			shuffleBytesValues.addElement(new ShuffleBytes((int)Math.pow(BASE, i), i));
//		}
//		shuffleBytes.setModel(shuffleBytesValues);
		
		this.shuffleBytes.setModel(GuiHelper.getShuffleBytesList());
		
		gc = new GridBagConstraints();
		
	}
	
	/**
	 * LAYOUT COMPONENT PLACEMENT.. 
	 */
	public void addComponents(){

		gc.gridy = 0;

		// FIRST ROW..		
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(selectFileLabel, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(filePathField, gc);
		

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(browseButton, gc);
		
		
		
		// SECOND ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;		
		this.add(selectShuffleBytesLabel, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;		
		this.add(this.shuffleBytes, gc);
		

		
		// THORD ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;		
		this.add(this.CloudsSelectionLabel, gc);
		
		
//		gc.gridx++;
//		gc.anchor = GridBagConstraints.LINE_END;		
//		gc.fill = GridBagConstraints.NONE;
//		this.add(this.Bucket1Label, gc);

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.bucket1, gc);		


		
		// FOURTH ROW..	
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 

		gc.gridx = 1;
//		gc.anchor = GridBagConstraints.LINE_END;
//		gc.fill = GridBagConstraints.NONE;		
//		this.add(this.Bucket2Label, gc);

//		gc.gridx++;
		
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.bucket2, gc);		
		
		
		
		// FIFTH ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 1;
//		gc.anchor = GridBagConstraints.LINE_END;
//		gc.fill = GridBagConstraints.NONE;
//		this.add(this.Bucket3Label, gc);
//		
//		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;		
		this.add(this.bucket3, gc);

		
		// SIXTH ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.1; 
		
		gc.gridx = 1;
//		gc.anchor = GridBagConstraints.LINE_END;
//		gc.fill = GridBagConstraints.NONE;		
//		this.add(this.Bucket4Label, gc);
//		
//		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;		
		this.add(this.bucket4, gc);

		
		
		// SEVENTH ROW..
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 2; 
		
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.uploadButton, gc);
		
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.cancelButton, gc);
		
		//this.pack();
	
	}
	
	
	/**
	 * upload button click
	 */
	public void UploadButtonClick(){
		// UPLOAD BUTTON CLICK..
				
		uploadButton.addActionListener( new ActionListener() {
			
			public void actionPerformed(ActionEvent event) {

				new Thread(new Runnable() {
					
					@Override
					public void run() {
						String filepath = filePathField.getText();
						ShuffleBytes selectedBytes = (ShuffleBytes)shuffleBytes.getSelectedItem();
						
						progressUpdater.updateProgress("Validating Upload Parameters..",PANELNAME.UPLOAD.toString());
						UploadFormValidation validationObject = new UploadFormValidation(filepath, selectedBytes, bucketEventHandler);
						
						if(validationObject.isValid()){
							if(bucketEventHandler.getSelectedBuckets().size() % 2 != 0){
								ShowMessageBox.showMessage("Please Select Even Number Of Buckets..");
							}else{
								UploadFormEvent ev = new UploadFormEvent(	this,
																			filepath,
																			selectedBytes,
																			bucketEventHandler.getSelectedBuckets(),
																			TargetUploadFile,
																			progressUpdater
																		);
									if(uploadFormListner != null){
										uploadFormListner.uploadFormEventOccured(ev);
									}
							}
						}else{
							ShowMessageBox.showMessage(validationObject.getMessage());
			//					System.out.println(validationObject.getMessage());
						}

						
					}
				}).start();
				
				
			}
		});
			
		
	}
	
	
	/**
	 * browse button click
	 */
	private void browseButtonClicked() {
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				browseButton.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						JFileChooser fileChooser = new JFileChooser();
						int result = fileChooser.showOpenDialog(null);
						
						if (result == JFileChooser.APPROVE_OPTION) {
						    File selectedFile = fileChooser.getSelectedFile();
						    TargetUploadFile = selectedFile;
						    filePathField.setText(selectedFile.getAbsolutePath());
						    SelectedFileName = selectedFile.getName();
						}
					}
				});
			}
		}).start();
		
	}
	
	/**
	 * 
	 * @param listner
	 */
	public void setFormListener(UploadFormListener uploadFormListener){
		this.uploadFormListner = uploadFormListener;
	}
	
	
	public void setProgressUpdater(ProgressUpdater progressUpdater){
		this.progressUpdater = progressUpdater;
	}
	
}
