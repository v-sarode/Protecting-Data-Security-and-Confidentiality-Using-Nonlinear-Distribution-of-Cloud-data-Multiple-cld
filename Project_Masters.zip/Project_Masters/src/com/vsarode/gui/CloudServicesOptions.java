package com.vsarode.gui;

public class CloudServicesOptions {
	
	private int value;
	private String cloudName;
	
	/**
	 * constructor for the creating object 
	 * @param value
	 * @param cloudName
	 */
	public CloudServicesOptions(int value, String cloudName) {
		super();
		this.value = value;
		this.cloudName = cloudName;
	}
	/**
	 * function to get selected cloud value 
	 * @return value integer value represeting particular cloud set 
	 */
	public int getValue() {
		return value;
	}
	
	/**
	 * setter to set cloud service 
	 * @param value integer for cloud selection in the gui panel 
	 */
	public void setValue(int value) {
		this.value = value;
	}
	
	/**
	 * function to get the name of the cloud service provider ..
	 * @return CloudName String name of cloud service provider 
	 */
	public String getCloudName() {
		return cloudName;
	}
	
	/**
	 * function to set the name of the cloud service provider ..
	 * @param CloudName String name of cloud service provider 
	 */
	public void setCloudName(String cloudName) {
		this.cloudName = cloudName;
	}
	
	
	@Override
	public String toString() {
		return this.cloudName;
	}
}
