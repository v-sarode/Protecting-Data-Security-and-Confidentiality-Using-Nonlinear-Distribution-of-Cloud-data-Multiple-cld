/**
 * GUI HELPER CLASS 
 */

package com.vsarode.gui;


import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.border.Border;

import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxAuthFinish;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxWebAuthNoRedirect;
import com.dropbox.core.v2.DbxClientV2;
import com.vsarode.controller.GuiHelperController;

public class GuiHelper {

	
	private static final String DROP_BOX_APP_KEY = GuiHelperController.getDROP_BOX_APP_KEY();
	private static final String DROP_BOX_APP_SECRET = GuiHelperController.getDROP_BOX_APP_SECRET();
	DbxClientV2 dbxClient;

	
	/** 
	 * function to generate url to forward user to the user 
	 * @return authorizeurl String url to forward web browser to user for getting access token
	 * @throws IOException
	 * @throws DbxException
	 */
	public static String getDBXKeyLink()
			throws IOException, DbxException {
		DbxAppInfo dbxAppInfo = new DbxAppInfo(DROP_BOX_APP_KEY, DROP_BOX_APP_SECRET);
		DbxRequestConfig dbxRequestConfig = new DbxRequestConfig(
				"JavaDropboxApplication/1.0", Locale.getDefault().toString());
		DbxWebAuthNoRedirect dbxWebAuthNoRedirect = new DbxWebAuthNoRedirect(
				dbxRequestConfig, dbxAppInfo);
		String authorizeUrl = dbxWebAuthNoRedirect.start();
		return authorizeUrl;
	}
	
	
	/**
	 * function to open the browser 
	 * @param URL String to visit url 
	 */
	public static void openBrowser(String URL){
		if(Desktop.isDesktopSupported()){
			try {
				Desktop.getDesktop().browse(new URI(URL));
			} catch (IOException | URISyntaxException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	/**
	 * function to get new dbx key 
	 * @return url String to visit url
	 */
	public static String getNewDbxKey(){
		String dbxKey = null;
		
//		JOptionPane msgBox = new JOptionPane();
		
		//ShowMessageBox.showMessage();
		String message = "DropBox Key is Expired Please Input New One in consecutive Prompt.";
		if(JOptionPane.showConfirmDialog(null, message, "Notice", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION){
			int delay = 1000; //milliseconds
			  ActionListener taskPerformer = new ActionListener() {
			      public void actionPerformed(ActionEvent evt) {
			    	  new Thread(new Runnable() {
						@Override
						public void run() {
							try {
								openBrowser(GuiHelper.getDBXKeyLink());
							} catch (IOException | DbxException e) {
								e.printStackTrace();
							}
						}
					}).start();
			      }
			  };
			  Timer myTimer = new Timer(delay, taskPerformer);
			  myTimer.setRepeats(false);
			  myTimer.start();

				try {
					Thread.sleep(2000);
					
					message = "DropBox Key is Expired Please Paste New One From Browser Below Input Box";
					dbxKey= JOptionPane.showInputDialog(message);
					
				} catch (InterruptedException e) {
				
					e.printStackTrace();
				}
			  
		}
		

		return dbxKey;
	}

	/**
	 * CREATE COMPOUND BORDER FOR THE CALLING PANEL
	 * @param borderTitle
	 * @return
	 */
	public static Border applyBorder(String borderTitle){
		
		Border outsideBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		Border insideBorder = BorderFactory.createTitledBorder(borderTitle+" SECTION");
		
		return BorderFactory.createCompoundBorder(outsideBorder, insideBorder);
	}
	
	/**
	 * function to create options list for shuffling bytes 
	 * @return shuffleBytesValues DefaultComboBoxModel<ShuffleBytes> options model to combobox for panel 
	 */
	public static DefaultComboBoxModel getShuffleBytesList(){
		DefaultComboBoxModel<ShuffleBytes> shuffleBytesValues = new DefaultComboBoxModel<ShuffleBytes>();
		
		final int BASE = 2;
		for(int i = 2; i < 11;i++){
			shuffleBytesValues.addElement(new ShuffleBytes((int)Math.pow(BASE, i), i));
		}
		
		return shuffleBytesValues;
	}	
	
}
