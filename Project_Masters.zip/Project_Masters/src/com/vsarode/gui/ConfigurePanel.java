package com.vsarode.gui;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.dropbox.core.DbxException;

public class ConfigurePanel extends JPanel {

	
	private JLabel bucketLabel_1;
	private JLabel bucketLabel_2;
	private JLabel bucketLabel_3;
	private JLabel bucketLabel_4;
	private JLabel dropboxkeyLabel;
	
	private JTextField bucketField_1;
	private JTextField bucketField_2;
	private JTextField bucketField_3;
	private JTextField bucketField_4;
	private JTextField dropboxkeyField;
	
	private JComboBox bucketList_1;
	private JComboBox bucketList_2;
	private JComboBox bucketList_3;
	private JComboBox bucketList_4;
	

	
	private ConfigureCSPOptions bucketListOptions_1;
	private ConfigureCSPOptions bucketListOptions_2;
	private ConfigureCSPOptions bucketListOptions_3;
	private ConfigureCSPOptions bucketListOptions_4;
	
	private JButton saveButton;
	private JButton dbxKeyButton;
	private JButton cancelButton;
	private ConfigureFormListener configureFormListener;
	
	private GridBagConstraints gc;

	private ProgressUpdater progressUpdater;
	private Panels PANEL;
	
	
	/**
	 * constructor configure panel..
	 */
	public ConfigurePanel() {
		initializeComponets();

		this.setBorder(GuiHelper.applyBorder(PANEL.CONFIGURE.toString()));
		this.setLayout(new GridBagLayout());
		this.addComponents();
		
		this.dbxKeyButtonCliked();
		this.saveButtonClicked();
		this.cancelButton.addActionListener(new CancelAction("Configure Panel"));
	}



	/**
	 * function to initialize the components into the panel..
	 */
	private void initializeComponets() {
		this.bucketLabel_1 = new JLabel("Bucket 1:");
		this.bucketLabel_2 = new JLabel("Bucket 2:");
		this.bucketLabel_3 = new JLabel("Bucket 3:");
		this.bucketLabel_4 = new JLabel("Bucket 4:");
		this.dropboxkeyLabel = new JLabel("Dropbox Key:");
		
		
		this.bucketField_1 = new JTextField();
		this.bucketField_2 = new JTextField();
		this.bucketField_3 = new JTextField();
		this.bucketField_4 = new JTextField();
		this.dropboxkeyField = new JTextField();

		this.bucketField_1.setMinimumSize(new Dimension(150, 22));
		this.bucketField_2.setMinimumSize(new Dimension(150, 22));
		this.bucketField_3.setMinimumSize(new Dimension(150, 22));
		this.bucketField_4.setMinimumSize(new Dimension(150, 22));
		this.dropboxkeyField.setMinimumSize(new Dimension(150, 22));
		
		this.bucketField_1.setPreferredSize(new Dimension(160, 22));
		this.bucketField_2.setPreferredSize(new Dimension(160, 22));
		this.bucketField_3.setPreferredSize(new Dimension(160, 22));
		this.bucketField_4.setPreferredSize(new Dimension(160, 22));
		this.dropboxkeyField.setPreferredSize(new Dimension(160, 22));
		
		this.bucketList_1 = new JComboBox();
		this.bucketList_2 = new JComboBox();
		this.bucketList_3 = new JComboBox();
		this.bucketList_4 = new JComboBox();
		
		this.saveButton = new JButton("Save");
		this.dbxKeyButton= new JButton("Get Key");
		this.cancelButton = new JButton("Cancel");
		
		
		bucketListOptions_1 = new ConfigureCSPOptions();
		bucketListOptions_2 = new ConfigureCSPOptions();
		bucketListOptions_3 = new ConfigureCSPOptions();
		bucketListOptions_4 = new ConfigureCSPOptions();
		
		bucketList_1.setModel(bucketListOptions_1);
		bucketList_2.setModel(bucketListOptions_2);
		bucketList_3.setModel(bucketListOptions_3);
		bucketList_4.setModel(bucketListOptions_4);
		
		bucketList_1.setPreferredSize(new Dimension(200, 22));
		bucketList_2.setPreferredSize(new Dimension(200, 22));
		bucketList_3.setPreferredSize(new Dimension(200, 22));
		bucketList_4.setPreferredSize(new Dimension(200, 22));
		
		gc = new GridBagConstraints();
	}
	
	/**
	 * function to add components to the configure panel
	 */
	private void addComponents() {
		gc.gridy = 0;

		// FIRST ROW..		
		gc.weightx = 0.2;
		gc.weighty = 0.5; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketLabel_1, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketField_1, gc);
		

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketList_1, gc);	
		
		
		// SECOND ROW..	
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.5;
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketLabel_2, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketField_2, gc);
		

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketList_2, gc);		

		
		// THIRD ROW..	
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.5; 
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketLabel_3, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketField_3, gc);
		

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketList_3, gc);		

		// FOURTH ROW..	
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.5;
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketLabel_4, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketField_4, gc);
		

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.bucketList_4, gc);		
		
		// FIFTH ROW..
		gc.gridy++;
		gc.weightx = 0.2;
		gc.weighty = 0.5;
		
		gc.gridx = 0;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.dropboxkeyLabel, gc);
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.dropboxkeyField, gc);

		gc.gridx++;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.dbxKeyButton, gc);
		

		// SIXTH ROW..	
		
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 2; 
		
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 5);
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.fill = GridBagConstraints.NONE;
		
		this.add(this.saveButton, gc);
		
		
		gc.gridx++;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.fill = GridBagConstraints.NONE;
		this.add(this.cancelButton, gc);
	}
	
	/**
	 * Save button click
	 */
	private void saveButtonClicked() {
				saveButton.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
						new Thread(new Runnable() {
							
							@Override
							public void run() {
						
								String  bucket1 = bucketField_1.getText();
								String  bucket2 = bucketField_2.getText();
								String  bucket3 = bucketField_3.getText();
								String  bucket4 = bucketField_4.getText();
								String dbxkey = dropboxkeyField.getText();
								CloudServicesOptions b1cloud = (CloudServicesOptions) bucketList_1.getSelectedItem();
								CloudServicesOptions b2cloud = (CloudServicesOptions) bucketList_2.getSelectedItem();
								CloudServicesOptions b3cloud = (CloudServicesOptions) bucketList_3.getSelectedItem();
								CloudServicesOptions b4cloud = (CloudServicesOptions) bucketList_4.getSelectedItem();
								
								progressUpdater.updateProgress("Validating Configure Parameters..",PANEL.CONFIGURE.toString());
		
								// validation check for the values in the panel
								ConfigureFormValidation validationObject = new ConfigureFormValidation(bucket1, 
																										bucket2, 
																										bucket3, 
																										bucket4, 
																										dbxkey, 
																										b1cloud, 
																										b2cloud, 
																										b3cloud, 
																										b4cloud
																										);
								
								if(validationObject.isValid()){
										// event generation for the handling into the another panel...
										ConfigureFormEvent ConfigureEvent = new ConfigureFormEvent(	this, 
																									dbxkey, 
																									bucket1, 
																									bucket2, 
																									bucket3, 
																									bucket4, 
																									b1cloud, 
																									b2cloud, 
																									b3cloud, 
																									b4cloud, 
																									progressUpdater
																								 	);
											if(configureFormListener != null){
												configureFormListener.ConfigureFormEventOccured(ConfigureEvent);
											}
		
								}else{
									ShowMessageBox.showMessage(validationObject.getMessage());
								}
								
							}
						}).start();
								
					}
				
				
				});				
		
	}

	
	/**
	 * function to handle get key button
	 */
	public void dbxKeyButtonCliked(){
		
		dbxKeyButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						if(Desktop.isDesktopSupported()){
							try {
								Desktop.getDesktop().browse(new URI(GuiHelper.getDBXKeyLink()));
							} catch (IOException | URISyntaxException e) {
								e.printStackTrace();
							} catch (DbxException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();
				
			}
		});
		

	}
	
	/**
	 * setting listener for handling event into the frame class..
	 * @param configureFormListener
	 */
	public void setConfigureFormListener(ConfigureFormListener configureFormListener){
		this.configureFormListener = configureFormListener;
	}
	
	/**
	 * function to handle update status in the status panel..
	 * @param progressUpdater
	 */
	public void setProgressUpdater(ProgressUpdater progressUpdater){
		this.progressUpdater = progressUpdater;
	}
	
	
}
