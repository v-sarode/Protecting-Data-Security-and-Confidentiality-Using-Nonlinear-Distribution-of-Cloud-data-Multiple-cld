package com.vsarode.gui;

import java.util.EventObject;

public class ConfigureFormEvent extends EventObject {


	private String dbxKey;
	private String bucket1;
	private String bucket2;
	private String bucket3;
	private String bucket4;
	private CloudServicesOptions b1cloud;
	private CloudServicesOptions b2cloud;
	private CloudServicesOptions b3cloud;
	private CloudServicesOptions b4cloud;
	private ProgressUpdater progressUpdater;

	public ConfigureFormEvent(Object source) {
		super(source);
	}

	public ConfigureFormEvent(Object source, String dbxKey, String bucket1,
			String bucket2, String bucket3, String bucket4,
			CloudServicesOptions b1cloud, CloudServicesOptions b2cloud,
			CloudServicesOptions b3cloud, CloudServicesOptions b4cloud,ProgressUpdater progressUpdater) {
		super(source);
		this.dbxKey = dbxKey;
		this.bucket1 = bucket1;
		this.bucket2 = bucket2;
		this.bucket3 = bucket3;
		this.bucket4 = bucket4;
		this.b1cloud = b1cloud;
		this.b2cloud = b2cloud;
		this.b3cloud = b3cloud;
		this.b4cloud = b4cloud;
		this.progressUpdater = progressUpdater;
	}
	
	
	public String getDbxKey() {
		return dbxKey;
	}

	public void setDbxKey(String dbxKey) {
		this.dbxKey = dbxKey;
	}

	public String getBucket1() {
		return bucket1;
	}

	public void setBucket1(String bucket1) {
		this.bucket1 = bucket1;
	}

	public String getBucket2() {
		return bucket2;
	}

	public void setBucket2(String bucket2) {
		this.bucket2 = bucket2;
	}

	public String getBucket3() {
		return bucket3;
	}

	public void setBucket3(String bucket3) {
		this.bucket3 = bucket3;
	}

	public String getBucket4() {
		return bucket4;
	}

	public void setBucket4(String bucket4) {
		this.bucket4 = bucket4;
	}

	public CloudServicesOptions getB1cloud() {
		return b1cloud;
	}

	public void setB1cloud(CloudServicesOptions b1cloud) {
		this.b1cloud = b1cloud;
	}

	public CloudServicesOptions getB2cloud() {
		return b2cloud;
	}

	public void setB2cloud(CloudServicesOptions b2cloud) {
		this.b2cloud = b2cloud;
	}

	public CloudServicesOptions getB3cloud() {
		return b3cloud;
	}

	public void setB3cloud(CloudServicesOptions b3cloud) {
		this.b3cloud = b3cloud;
	}

	public CloudServicesOptions getB4cloud() {
		return b4cloud;
	}

	public void setB4cloud(CloudServicesOptions b4cloud) {
		this.b4cloud = b4cloud;
	}

	public ProgressUpdater getProgressUpdater() {
		return progressUpdater;
	}

	public void setProgressUpdater(ProgressUpdater progressUpdater) {
		this.progressUpdater = progressUpdater;
	}

	
	
}
