package com.vsarode.gui;

public class ProgressUpdater{
	
	private ProgressPanel progressPanel;
	
	public ProgressUpdater(ProgressPanel progressPanel){
		this.progressPanel = progressPanel;
	}


	/**
	 * function to update the status of any event 
	 * @param ProgressStatus String message of the status to be updated on the status panel
	 * @param source event source
	 */
	public void updateProgress(String ProgressStatus, String source) {
		progressPanel.updateStatus(this.createStatus(ProgressStatus, source));
	}

	
	/**
	 * function to generate status message before sending to the status panel for identification from particular panel and event.
	 * @param Message
	 * @param source
	 * @return message String value of the message which will be appended to the status panel.
	 */
	public String createStatus(String Message,String source){
		String Prefix = " ["+source+" PANEL] : ";
		return "\n"+StatusHelper.getDateTimeString()+Prefix+Message;
	}


	
}

