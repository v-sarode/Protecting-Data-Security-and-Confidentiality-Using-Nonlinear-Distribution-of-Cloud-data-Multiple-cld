package com.vsarode.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JCheckBox;

public class UploadFormBucketEventHandler implements ItemListener {

	private int selectedBucketCount = 0;
	private Set<String> selectedBuckets = new HashSet<String>();
	
	
	/**
	 * function to check value of the item selected 
	 * @param ItemClickEvent ItemEvent 
	 */
	public void itemStateChanged(ItemEvent ItemClickEvent) {
		JCheckBox Item = (JCheckBox)ItemClickEvent.getItem();
		
		String BucketName = Item.getText();
		
		switch (BucketName) {
		case "Bucket_1":

			this.checkBucketSelection(Item,ItemClickEvent);
			break;

		case "Bucket_2":
			this.checkBucketSelection(Item,ItemClickEvent);
			break;

		case "Bucket_3":
			this.checkBucketSelection(Item,ItemClickEvent);
			break;

		case "Bucket_4":
			this.checkBucketSelection(Item,ItemClickEvent);
			break;

		default:
			break;
		}

	}
	
	
	/**
	 * function to check the selection of the buckets from the upload panel 
	 * @param Item JCHeckBox
	 * @param ItemClickEvent ItemEvent
	 */
	public void checkBucketSelection(JCheckBox Item,ItemEvent ItemClickEvent){
	
		if(ItemClickEvent.getStateChange() == 1){
			this.selectedBucketCount++;
			this.selectedBuckets.add(Item.getText());
		}else{
			this.selectedBucketCount--;
			this.selectedBuckets.remove(Item.getText());
		}
	}

	/**
	 * function to get selected bucket
	 * @return selectedBuckets set<String>
	 */
	public Set<String> getSelectedBuckets(){
		return this.selectedBuckets;
	}
	
	/**
	 * function to get selected bucket count
	 * @return selectedBucketCount integer 
	 */
	public int getSelectedBucketCount(){
		return this.selectedBucketCount;
	}
}
