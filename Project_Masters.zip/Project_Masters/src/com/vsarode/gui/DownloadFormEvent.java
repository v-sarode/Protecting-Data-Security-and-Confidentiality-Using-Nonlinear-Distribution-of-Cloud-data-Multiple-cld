package com.vsarode.gui;

import java.util.EventObject;
import java.util.List;

public class DownloadFormEvent extends EventObject {

	private String outputDirectory;
	private ShuffleBytes selectedBytes;
	private ProgressUpdater progressUpdater;
	private String targetDownloadFile;
	private List<? extends Object> bucketFileList;
	
	public DownloadFormEvent(Object source) {
		super(source);

	}
	
	public DownloadFormEvent(Object source,String outputDirectory,ShuffleBytes selectedBytes,String targetDownloadFile,ProgressUpdater progressUpdater){
		super(source);
		this.outputDirectory = outputDirectory;
		this.selectedBytes = selectedBytes;
		this.progressUpdater = progressUpdater;
		this.targetDownloadFile = targetDownloadFile;
	}
	

	public DownloadFormEvent(Object source,String outputDirectory,ShuffleBytes selectedBytes,String targetDownloadFile,List<? extends Object> bucketFileList,ProgressUpdater progressUpdater){
		super(source);
		this.outputDirectory = outputDirectory;
		this.selectedBytes = selectedBytes;
		this.progressUpdater = progressUpdater;
		this.targetDownloadFile = targetDownloadFile;
		this.bucketFileList = bucketFileList;
	}
	

	public String getOutputDirectory() {
		return outputDirectory;
	}


	public void setOutputDirectory(String outputDirectory) {
		this.outputDirectory = outputDirectory;
	}


	public ShuffleBytes getSelectedBytes() {
		return selectedBytes;
	}


	public void setSelectedBytes(ShuffleBytes selectedBytes) {
		this.selectedBytes = selectedBytes;
	}


	public ProgressUpdater getProgressUpdater() {
		return progressUpdater;
	}


	public void setProgressUpdater(ProgressUpdater progressUpdater) {
		this.progressUpdater = progressUpdater;
	}

	public String getTargetDownloadFile() {
		return targetDownloadFile;
	}

	public void setTargetDownloadFile(String targetDownloadFile) {
		this.targetDownloadFile = targetDownloadFile;
	}

	public List<? extends Object> getBucketFileList() {
		return this.bucketFileList;
	}

	public void setBucketFileList(List<? extends Object> bucketFileList) {
		this.bucketFileList = bucketFileList;
	}
	
}
