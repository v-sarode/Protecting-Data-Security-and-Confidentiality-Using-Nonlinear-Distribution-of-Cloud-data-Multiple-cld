package com.vsarode.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class CancelAction implements ActionListener {
	private String panel;
	
	/**
	 * CONSTRUCTOR..
	 * @param panel
	 */
	public CancelAction(String panel) {
		this.panel = panel;
	}


	/**
	 * FUNCTION TO EXIT FROM APPLICATION WITH PROMPT..
	 */
	public void actionPerformed(ActionEvent e) {
		new Thread(new Runnable() {			
			public void run() {
				JOptionPane msgBox = new JOptionPane();
				String message = "Are you sure you want to cancel from "+panel+"?\nSystem will Exit !!";
				
//				if(msgBox.showConfirmDialog(null, message) == JOptionPane.OK_OPTION){
//					System.exit(0);
//				}				
				if(msgBox.showConfirmDialog(null, message, "Cancel Click", 2, JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION){
					System.exit(0);
				}
			}
		}).start();
	}

	
	@Override
	public String toString() {	
		return this.panel+"Cancel Action Class";
	}
	
}
