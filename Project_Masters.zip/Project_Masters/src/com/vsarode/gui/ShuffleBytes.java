package com.vsarode.gui;

public class ShuffleBytes {

	private int shuffleBytes;
	private int calculationValue = 0;
	
	/**
	 * constructor for the shuffle byte to hold bytes and the actual value to generate finite table 
	 * @param shuffleBytes
	 * @param calculationValue
	 */
	public ShuffleBytes(int shuffleBytes,int calculationValue) {
		this.shuffleBytes = shuffleBytes;
		this.calculationValue = calculationValue;
	}
	
	@Override
	public String toString() {
		return Integer.toString(this.shuffleBytes);
	}
	
	
	/**
	 * Actual value to calculate the galois table
	 * @return
	 */
	public int getValue(){
		return this.calculationValue;
	}
	
	/**
	 * Actual bytes to shuffle
	 * @return
	 */
	public int getShuffleBytes(){
		return shuffleBytes; 
	}
	
}
