package com.vsarode.gui;

import javax.swing.JOptionPane;

public class ShowMessageBox {
	
	
	/**
	 * function to show message to the user in prompt.
	 * @param Message
	 */
	public static void showMessage(final String Message){
		//JOptionPane MessageBox = new JOptionPane();
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				JOptionPane.showConfirmDialog(null, Message, "Interrupt", 0, JOptionPane.INFORMATION_MESSAGE);
		//		msgBox.showConfirmDialog(null, message, "Cancel CLick", 2, JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION);
			}
		}).start();
	}
	
}
