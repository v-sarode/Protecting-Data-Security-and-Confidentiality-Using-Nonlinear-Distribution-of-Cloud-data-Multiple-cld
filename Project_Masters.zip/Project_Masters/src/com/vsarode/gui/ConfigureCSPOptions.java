package com.vsarode.gui;

import javax.swing.DefaultComboBoxModel;

public class ConfigureCSPOptions extends
		DefaultComboBoxModel<CloudServicesOptions> {

	public ConfigureCSPOptions() {
		this.addElement(new CloudServicesOptions(1, "Amazon"));
		this.addElement(new CloudServicesOptions(2, "Dropbox"));
	}
}
