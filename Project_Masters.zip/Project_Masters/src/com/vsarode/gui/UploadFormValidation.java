package com.vsarode.gui;

public class UploadFormValidation {

	private String message;
	private ShuffleBytes selectedShuffleBytes;
	private String FilePath;
	private UploadFormBucketEventHandler bucketEventHandler;
	
	public UploadFormValidation(String FilePath,ShuffleBytes selectedShuffleBytes,UploadFormBucketEventHandler bucketEventHandler) {
		this.FilePath = FilePath;
		this.selectedShuffleBytes = selectedShuffleBytes;
		this.bucketEventHandler = bucketEventHandler;
	}
	
	/**
	 * function to check the validation of all the fields in the object 
	 * @return status boolean true/false value of the all the fields values 
	 */
	public boolean isValid(){
		boolean test1,test2,test3 ;
		test1=test2=test3=true;
		
		String emptyParameters = "";
		String separator = " ,";
		
		if(this.selectedShuffleBytes.getValue() == 0){
			emptyParameters += "Select-Shuffle-Bytes"+separator;
			test1= false;
		}

		
		if(this.FilePath.isEmpty()){
			emptyParameters += "Select-Upload-File"+separator;
			test2 = false;
		}
		
		if(this.bucketEventHandler.getSelectedBuckets().size() == 0){
			emptyParameters += "Select-Buckets"+separator;
			test3 = false;
		}
		
		this.message = "Please Fill "+emptyParameters;
		this.message = this.message.substring(0, this.message.length()-1);
		return (test1&test2&test3);
	}
	
	/**
	 * function to get the message
	 * @return message String
	 */
	public String getMessage(){
		return this.message.trim();
	}
	
}
