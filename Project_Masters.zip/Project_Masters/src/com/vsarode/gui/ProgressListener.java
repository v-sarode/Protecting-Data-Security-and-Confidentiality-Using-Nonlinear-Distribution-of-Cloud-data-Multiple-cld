package com.vsarode.gui;

public interface ProgressListener {
	public  void updateProgress(String ProgressStatus);
}
