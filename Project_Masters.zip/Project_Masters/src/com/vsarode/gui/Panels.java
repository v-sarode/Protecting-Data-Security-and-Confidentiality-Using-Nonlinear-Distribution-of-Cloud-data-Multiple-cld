package com.vsarode.gui;

public enum Panels {
	UPLOAD,DOWNLOAD,CONFIGURE;
}
