package com.vsarode.gui;

public class DownloadFormValidation {

	private String message;
	private ShuffleBytes selectedShuffleBytes;
	private String FilePath;
	private String targetDownloadFile;
	
	public DownloadFormValidation(String FilePath,ShuffleBytes selectedShuffleBytes,String targetDownloadFile) {
		this.FilePath = FilePath;
		this.selectedShuffleBytes = selectedShuffleBytes;
	
		this.targetDownloadFile = targetDownloadFile;
	}

	
	public boolean isValid(){
		boolean test1,test2,test3 ;
		test1=test2=test3=true;
		
		String emptyParameters = "";
		String separator = " ,";
		
		if(this.selectedShuffleBytes.getValue() == 0){
			emptyParameters += "Select-Shuffle-Bytes"+separator;
			test1= false;
		}
		
		
		if(this.FilePath.isEmpty()){
			emptyParameters += "Select-Download-Location"+separator;
			test2 = false;
		}
		
		if(this.targetDownloadFile.isEmpty()){
			emptyParameters += "Select-Download-File"+separator;
			test2 = false;
		}
		
		this.message = "Please Fill "+emptyParameters;
		this.message = this.message.substring(0, this.message.length()-1);
		return (test1&test2&test3);
	}
	
	public String getMessage(){
		return this.message.trim();
	}


	public String getTargetDownloadFile() {
		return targetDownloadFile;
	}


	public void setTargetDownloadFile(String targetDownloadFile) {
		this.targetDownloadFile = targetDownloadFile;
	}
	

}
