package com.vsarode.gui;

public interface ConfigureFormListener {
	public void ConfigureFormEventOccured(ConfigureFormEvent configureEvent);
}
