package com.vsarode.gui;

import java.io.File;
import java.util.EventObject;
import java.util.HashSet;
import java.util.Set;

public class UploadFormEvent extends EventObject {

	
	private String filepath;
	private ShuffleBytes bytesToShuffle;
	private HashSet<String> selctedBuckets;
	private ProgressUpdater progressUpdater;
	private File TargetUploadFile;
	
	/**
	 * DEFAULT CONSTRUCTOR..
	 * @param source
	 */
	public UploadFormEvent(Object source) {
		super(source);		
	}

	
	public UploadFormEvent(Object source,String filepath,ShuffleBytes bytesToShuffle, Set selectedBuckets,File TargetUploadFile, ProgressUpdater progressUpdater) {
		super(source);		
		this.filepath = filepath;
		this.bytesToShuffle = bytesToShuffle;
		this.selctedBuckets = (HashSet) selectedBuckets;
		this.TargetUploadFile = TargetUploadFile;
		this.progressUpdater = progressUpdater;
	}


	public String getFilepath() {
		return filepath;
	}


	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}


	public ShuffleBytes getBytesToShuffle() {
		return bytesToShuffle;
	}


	public void setBytesToShuffle(ShuffleBytes bytesToShuffle) {
		this.bytesToShuffle = bytesToShuffle;
	}


	public HashSet<String> getSelctedBuckets() {
		return selctedBuckets;
	}


	public void setSelctedBuckets(HashSet<String> selctedBuckets) {
		this.selctedBuckets = selctedBuckets;
	}


	public ProgressUpdater getProgressUpdater() {
		return progressUpdater;
	}


	public void setProgressUpdater(ProgressUpdater progressUpdater) {
		this.progressUpdater = progressUpdater;
	}


	public File getTargetUploadFile() {
		return TargetUploadFile;
	}


	public void setTargetUploadFile(File targetUploadFile) {
		TargetUploadFile = targetUploadFile;
	}

}
