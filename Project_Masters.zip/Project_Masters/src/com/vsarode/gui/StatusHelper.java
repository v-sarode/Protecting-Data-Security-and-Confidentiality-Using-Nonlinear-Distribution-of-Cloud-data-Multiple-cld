package com.vsarode.gui;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class StatusHelper {
	
	/**
	 * function to get the time in string  
	 * @return datetime String value 
	 */
	public static String getDateTimeString(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	
	/**
	 * function to update the statius 
	 * @param Message String 
	 */
	public void updateStatus(String Message){
		String Prefix = " [UPLOAD PANEL] : ";
		String Status = StatusHelper.getDateTimeString()+Prefix+Message;
	}
	
	
}
