package com.vsarode.controller;

import java.util.List;
import java.util.Set;

import com.vsarode.model.BucketFile;
import com.vsarode.model.BucketFilesListHolder;

public class BucketListHolder {
	BucketFilesListHolder bucketListObject;
	Set<String> fileSet;
	List<BucketFile> fileList;
	
	/**
	 * constructor for the data type to pass into the gui panel..
	 * @param bucketListObject
	 */
	public BucketListHolder(BucketFilesListHolder bucketListObject) {
		this.bucketListObject = bucketListObject;
		this.setFileList(this.bucketListObject.getFilesList());
		this.setFileSet(this.bucketListObject.getFilesSet());
	}


	/**
	 * getter for the files list
	 * @return
	 */
	public Set<String> getFileSet() {
		return fileSet;
	}


	/**
	 * setter for the filelist..
	 * @param fileSet
	 */
	public void setFileSet(Set<String> fileSet) {
		this.fileSet = fileSet;
	}


	/**
	 * getter for the file list..
	 * @return
	 */
	public List<BucketFile> getFileList() {
		return fileList;
	}


	/**
	 * setter for the file list
	 * @param fileList
	 */
	public void setFileList(List<BucketFile> fileList) {
		this.fileList = fileList;
	}
	
	
	
	
}
