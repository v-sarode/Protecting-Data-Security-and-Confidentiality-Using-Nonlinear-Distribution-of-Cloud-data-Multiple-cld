package com.vsarode.controller;

import com.vsarode.gui.ConfigureFormEvent;
import com.vsarode.model.BucketConfigurations;

public class ConfigureController {
	
	ConfigureFormEvent configureEvent;
	
	/**
	 * CONSTRUCTOR
	 * @param configureEvent CONFIGUREVENT FROM THE GUI PART 
	 */
	public ConfigureController(ConfigureFormEvent configureEvent) {
		this.configureEvent = configureEvent;
	}
	
	
	/**
	 * FUNCTION TO SAVE THE CONFIGURATION PROVIDED BY THE GUI TO SETTINGS FILE 
	 */
	public void SaveConfiguration(){
		this.configureEvent.getProgressUpdater().updateProgress(" Saving Settings.. ", "CONFIGURE");
		
		boolean status = BucketConfigurations.saveAppProperties(	
												
												//''this.configureEvent.getDbxKey(),
											//	"xvT6EjEdor8AAAAAAAADfJRnOcaLVYU0X4jGLw3buR6N7MKSD4wiJTT4aa7RrkzU",
												this.configureEvent.getDbxKey(),
												
												this.configureEvent.getBucket1(),
												this.configureEvent.getBucket2(),
												this.configureEvent.getBucket3(),
												this.configureEvent.getBucket4(),
												
												this.configureEvent.getB1cloud(),
												this.configureEvent.getB2cloud(),
												this.configureEvent.getB3cloud(),
												this.configureEvent.getB4cloud()
												);
		
		if(status){
			this.configureEvent.getProgressUpdater().updateProgress(" Saving Saved Successfully.. ", "CONFIGURE");	
		}else{
			this.configureEvent.getProgressUpdater().updateProgress(" [Error] : In Saving Settings.. ", "CONFIGURE");
		}
	}
	
	

}
