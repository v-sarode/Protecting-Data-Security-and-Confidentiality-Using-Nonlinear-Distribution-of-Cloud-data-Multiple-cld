package com.vsarode.controller;

import com.vsarode.model.BucketConfigurations;
import com.vsarode.model.DbxAppValues;
import com.vsarode.model.DbxHelper;
import com.vsarode.model.DownloadFileListGenerator;



public class GuiHelperController {

	/**
	 * FUNCTION TO HELP GUI FOR CHECK STATUS OF DBXKEY VALID OR NOT..
	 * @return TRUE/FALSE
	 */
	public static boolean checkDbxKey(){
		return DbxHelper.isKeyValid();
	}
	
	
	/**
	 * FUNCTION TO SET NEW DROPBOX KEY...
	 * @param DbxKey
	 */
	public static void setNewDbxKey(String DbxKey){
		BucketConfigurations.setNewDbxKey(DbxKey);
	}
	
	/**
	 * FUNCTION FOR DROPBOX KEY OF THE APPLICATION 
	 * @return String DROPBOX APPLICATION KEY
	 */
	public static String getDROP_BOX_APP_KEY() {
		return DbxAppValues.getDROP_BOX_APP_KEY();
	}
	
	
	/**
	 * FUNCTION FOR DROPBOX APP SECRET OF THE APPLICATION 
	 * @return String DROPBOX APPLICATION APP SECRET 
	 */	
	public static String getDROP_BOX_APP_SECRET() {
		return DbxAppValues.getDROP_BOX_APP_SECRET();
	}

	
	/**
	 * FUNCTION FOR OBJECT HOLDING SET AND LIST OF BUCKET FILES FROM MODEL TO SEND IN GUI..
	 * @return 	BucketListHolder CLASS WITH LIST<BUCKETFILE> AND SET<STRING> FOR LIST OF FILES IN THE BUCKET.. 
	 */
	public static BucketListHolder getFilesListObject(){
		return new BucketListHolder(DownloadFileListGenerator.getFilesList());
	}
	
	
	
	
}
