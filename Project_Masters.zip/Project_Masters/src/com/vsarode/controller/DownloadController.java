package com.vsarode.controller;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.vsarode.gui.DownloadFormEvent;
import com.vsarode.model.BucketConfigurations;
import com.vsarode.model.BucketFile;
import com.vsarode.model.DownloadFileListGenerator;
import com.vsarode.model.DownloadFiles;
import com.vsarode.model.DownloadHelper;
import com.vsarode.model.FiniteField;
import com.vsarode.model.Merger;

public class DownloadController {
	
	private DownloadFormEvent downloadEvent;
	private FiniteField finiteField;
	
	/**
	 * Constructor to handle download operation 
	 * @param downloadEvent
	 */
	public DownloadController(DownloadFormEvent downloadEvent) {
		this.downloadEvent = downloadEvent;
		finiteField = new FiniteField(downloadEvent.getSelectedBytes().getValue());
	}

	/**
	 * Constructor to handle download operation..
	 * @param downloadEvent
	 * @param DbxKey
	 */
	public DownloadController(DownloadFormEvent downloadEvent,String DbxKey) {
		this.downloadEvent = downloadEvent;
		BucketConfigurations.setNewDbxKey(DbxKey);
		finiteField = new FiniteField(downloadEvent.getSelectedBytes().getValue());
	}
	
	
	/**
	 * FUNCTION TO START THE DOWNLOADING FILE
	 */
	public void startDownloadingProcess(){
	
	
		String[] FileList = null;
		HashMap<Integer, String> C2FMap = null;
		DownloadFiles downLoadFilesObject = new DownloadFiles();
		Merger merger = new Merger();
		
		this.downloadEvent.getProgressUpdater().updateProgress(" Selected File For Download : "+this.downloadEvent.getTargetDownloadFile(), "DOWNLOAD");
		this.downloadEvent.getProgressUpdater().updateProgress(" Preparing List Download Files List", "DOWNLOAD");
				
		// PREPARING LISTS FOR THE FILES DOWNLOAD...
		List<BucketFile> fileList = (List<BucketFile>) this.downloadEvent.getBucketFileList();
		
		BucketFile selectedFile = DownloadHelper.SortFiles(fileList, 
															this.downloadEvent.getTargetDownloadFile()
														   );
		
		if(selectedFile != null){
			FileList = DownloadHelper.createTargetFileList(selectedFile);
			C2FMap = DownloadHelper.getC2FMaping(selectedFile);
		}
		
		this.downloadEvent.getProgressUpdater().updateProgress(" Download Files List Prepared...", "DOWNLOAD");

		
		
		this.downloadEvent.getProgressUpdater().updateProgress(" Downloading Files From Buckets...", "DOWNLOAD");
		long timeBeforeDownloadingFile = System.currentTimeMillis();

		// LOGIC FOR DOWNLOADING FILES ..
		
		try {
		
			downLoadFilesObject.downloadAllFiles(C2FMap, this.downloadEvent.getOutputDirectory());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		this.downloadEvent.getProgressUpdater().updateProgress(" All Files Downloaded Successfully", "DOWNLOAD");
		long timeAfterDownloadingFile = System.currentTimeMillis();
		long filesDownloadTime = (timeAfterDownloadingFile-timeBeforeDownloadingFile);
		String downloadingTime = String.format("%.3f seconds",(filesDownloadTime/1000.0f));
		this.downloadEvent.getProgressUpdater().updateProgress(" Total Time To Download Files: "+downloadingTime, "DOWNLOAD");

		
		
		this.downloadEvent.getProgressUpdater().updateProgress(" Creating Original File From Downloaded Files", "DOWNLOAD");
		long timeBeforeMergingFiles = System.currentTimeMillis();
		
		
		// LOGIC FOR MERGIN FILE
		if(FileList.length == 2){
			merger.merge2Files(
								FileList, 
								this.downloadEvent.getTargetDownloadFile(), 
								this.finiteField, 
								this.downloadEvent.getSelectedBytes().getShuffleBytes(),
								this.downloadEvent.getOutputDirectory()
								);
		}else{
			merger.merge4Files(
								FileList, 
								this.downloadEvent.getTargetDownloadFile(), 
								this.finiteField, 
								this.downloadEvent.getSelectedBytes().getShuffleBytes(),
								this.downloadEvent.getOutputDirectory()
								);					
		}
		
		
		long timeAfterMergingFile = System.currentTimeMillis();
		long filesMergingTime = (timeAfterMergingFile-timeBeforeMergingFiles);
		String mergingFilesTime = String.format("%.3f seconds",(filesMergingTime/1000.0f));

		this.downloadEvent.getProgressUpdater().updateProgress(" Time To Merge & De-Shuffle Files: "+mergingFilesTime, "DOWNLOAD");
		

// 		open the file download directory...
		if (Desktop.isDesktopSupported()) {
		    try {
				Desktop.getDesktop().open(new File(downloadEvent.getOutputDirectory()));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * FUNCTION TO GENERATE THE LIST OF DOWNLOAD FILES FROM THE BUCKET
	 * @return fileList SET OF STRING CONTAINING THE FILES 
	 */
	public static Set<String> generateList(){
		Set<String> fileList= DownloadFileListGenerator.getFileList();
		return fileList;
	} 
	
}
