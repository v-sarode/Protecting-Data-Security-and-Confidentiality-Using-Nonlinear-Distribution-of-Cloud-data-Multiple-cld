package com.vsarode.controller;

import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import com.dropbox.core.DbxException;
import com.vsarode.gui.UploadFormEvent;
import com.vsarode.model.BucketConfigurations;
import com.vsarode.model.FileBreakHelper;
import com.vsarode.model.FileNameOperations;
import com.vsarode.model.FiniteField;
import com.vsarode.model.ShuffleBreakFile;
import com.vsarode.model.UploadFilesOperation;

public class UploadController {

	UploadFormEvent uploadEvent;
	FiniteField finiteField;
	
	/**
	 * CONSTRUCTOR..
	 * @param uploadEvent UPLOAD EVENT TRIGGERED BY THE GUI
	 */
	public UploadController(UploadFormEvent uploadEvent) {
		this.uploadEvent = uploadEvent;
		this.finiteField = new FiniteField(uploadEvent.getBytesToShuffle().getValue());
	}

//	  System.out.format("%.3f", sec);
	
	/**
	 * CONSTRUCTOR..
	 * @param uploadEvent UPLOAD EVENT TRIGGERED BY THE GUI
	 * @param DbxKey DROPBOX KEY..
	 */
	public UploadController(UploadFormEvent uploadEvent,String DbxKey) {
		this.uploadEvent = uploadEvent;
		BucketConfigurations.setNewDbxKey(DbxKey);
		this.finiteField = new FiniteField(uploadEvent.getBytesToShuffle().getValue());
	}

	
	/**
	 * FUNCTION TO START THE UPLOADING OF FILE ONTO THE CLOUDS..
	 * @return status boolean TRUE/FALSE STATUS
	 */
	public boolean startUploadingFiles(){
		
		File targetFile= this.uploadEvent.getTargetUploadFile();
		ShuffleBreakFile shuffleBreakFileObject = new ShuffleBreakFile(finiteField.getGF_LOG());
		String[] FileNamesArray = FileBreakHelper.getFileNamesArray((ArrayList<String>)FileNameOperations.createFileNames(this.uploadEvent.getTargetUploadFile().getAbsolutePath(), this.uploadEvent.getSelctedBuckets()));

		
		this.uploadEvent.getProgressUpdater().updateProgress(" Selected File Name: " +this.uploadEvent.getTargetUploadFile().getAbsolutePath(), "UPLOAD");
		this.uploadEvent.getProgressUpdater().updateProgress(" File Size:  "+getFileSize(this.uploadEvent.getTargetUploadFile()), "UPLOAD");
		this.uploadEvent.getProgressUpdater().updateProgress(" Shuffling Bytes Size:  "+this.uploadEvent.getBytesToShuffle(), "UPLOAD");
		
		this.uploadEvent.getProgressUpdater().updateProgress(" Breaking Files ", "UPLOAD");
		long timeBeforeBreakingFile = System.currentTimeMillis();
		shuffleBreakFileObject.startToBreakShuffleFile(	this.uploadEvent.getTargetUploadFile().getAbsolutePath(),
														FileNamesArray ,
														this.uploadEvent.getBytesToShuffle().getShuffleBytes()
														);
		
		long timeAfterBreakingFile = System.currentTimeMillis();
		long millis = (timeAfterBreakingFile-timeBeforeBreakingFile);
		String breakingTime = String.format("%.3f seconds",(millis/1000.0f));
		this.uploadEvent.getProgressUpdater().updateProgress(" Shufflig And Breaking Time : "+breakingTime, "UPLOAD");		
		this.uploadEvent.getProgressUpdater().updateProgress(" Breaking Files Completed Sucessfully", "UPLOAD");		
		
		
		HashMap<String,String>	C2FMap =  FileNameOperations.createC2FHashMap(this.uploadEvent.getTargetUploadFile().getAbsolutePath(), this.uploadEvent.getSelctedBuckets());
		
		this.uploadEvent.getProgressUpdater().updateProgress(" Uploading Files Started ", "UPLOAD");
		long timeBeforeUploadingFile = System.currentTimeMillis();

		try {
			UploadFilesOperation.uploadAll(C2FMap);
		} catch (DbxException | IOException e) {
			e.printStackTrace();
		}
		
		long timeAfterUploadingFile = System.currentTimeMillis();
		long millis1 = (timeAfterUploadingFile-timeBeforeUploadingFile);
		String uploadingTime = String.format("%.3f seconds",(millis1/1000.0f));
		this.uploadEvent.getProgressUpdater().updateProgress(" Total File Uploading Time : "+uploadingTime, "UPLOAD");
		this.uploadEvent.getProgressUpdater().updateProgress(" Uploading Files Completed Sucessfully", "UPLOAD");		
		
		return true;
	}
	
	
	/**
	 * function to generate file size in KB,MB,GB from bytes 
	 * @param file
	 * @return Filesize String 
	 */
	public static String getFileSize(File file){
		double bytes = file.length();
		String size = "";
		if(bytes > 1024){
			bytes = bytes/1024;
			size = String.format("%.2f", bytes);
			size += " KB";
		}
		if(bytes > 1024){
			bytes = bytes/1024;
			size = String.format("%.2f", bytes);
			size += " MB";
		}
		if(bytes > 1024){
			bytes = bytes/1024;
			size = String.format("%.2f", bytes);
			size += " GB";
		}
		return size;
	}
}
