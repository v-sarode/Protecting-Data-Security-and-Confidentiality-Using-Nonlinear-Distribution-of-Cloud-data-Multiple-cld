package com.vsarode.model;

import java.util.List;
import java.util.Set;

public class BucketFilesListHolder {

	Set<String> filesSet;
	List<BucketFile> filesList;
	
	/**
	 * SETTER
	 * @return
	 */
	public Set<String> getFilesSet() {
		return filesSet;
	}
	
	/**
	 * SETTER
	 * @param filesSet
	 */
	public void setFilesSet(Set<String> filesSet) {
		this.filesSet = filesSet;
	}
	
	/**
	 * GETTER
	 * @return
	 */
	public List<BucketFile> getFilesList() {
		return filesList;
	}
	
	/**
	 * GETTER
	 * @param filesList
	 */
	public void setFilesList(List<BucketFile> filesList) {
		this.filesList = filesList;
	}
	
	
}
