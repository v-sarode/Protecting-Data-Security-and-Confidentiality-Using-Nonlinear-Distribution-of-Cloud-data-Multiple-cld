package com.vsarode.model;

import java.util.ArrayList;

public class FileBreakHelper {

	/**
	 * function to get file names to break the orignal file
	 * @param fileNamesList
	 * @return FileNamesArray String Array containing the names of the subfiles in which original files will get divided
	 */
	public static String[] getFileNamesArray(ArrayList<String> fileNamesList){
		String[] FileNamesArray = new String[fileNamesList.size()];
		
		int count = 0;
		
		for (String s : fileNamesList) {
			FileNamesArray[count] = s;
			count++;
		}
		
		return FileNamesArray;
	}
}
