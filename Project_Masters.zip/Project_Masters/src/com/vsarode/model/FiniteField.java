
/**
 * 
 * FOR IRRIDUCUBLE POLYNOMIAL VALUES REFERENCE ....
 * http://web.eecs.utk.edu/~plank/plank/papers/CS-07-593/primitive-polynomial-table.txt
 * 
 */

package com.vsarode.model;

public class FiniteField {
	
	/**
	 * STATIC VARIABLES DECLARATION...
	 */
	public static int primePoly2_U = 007;
	public static int primePoly3_U = 013;
	public static int primePoly4_U = 023;
	public static int primePoly5_U = 045;
	public static int primePoly6_U = 103;
	public static int primePoly7_U = 211;
	public static int primePoly8_U = 0435;
	public static int primePoly9_U = 1021;
	public static int primePoly10_U = 2011;	
	
	public static short[] GF_LOG, GF_INVERSE_LOG;

	public FiniteField(int size) {
		this.createFiniteField(size);
	}

	/**
	 * @DESC METHOD CALCULATES THE GFLOG AND INVERSE GFLOG TABLES FOR FINITE NUMBER OF VALUES W
	 * @param power POLYNOMIAL OF W
	 * @return 0 AS A COMPLETION OF OPERATION.
	 * @REF THIS METHOD IS PORTED FROM C CODE TO JAVA .. FROM THE PAPER PUBLISHED BY JAMES PLANK
	 */
	private static int createFiniteField(int power) {
		int b_U = 0;
		int xToW_U = 0;
		int primePoly_U = 0;

		final int posDefault = 1;
		for(int pos = 0; true;) {
			switch(pos == posDefault ? "#" + pos : "" + power) {
			case "" + 2:
				primePoly_U = primePoly2_U;
				break;
			case "" + 3:
				primePoly_U = primePoly3_U;
				break;
			
			case "" + 4:
				primePoly_U = primePoly4_U;
				break;
			case "" + 5:
				primePoly_U = primePoly5_U;
				break;
			case "" + 6:
				primePoly_U = primePoly6_U;
				break;
			case "" + 7:
				primePoly_U = primePoly7_U;
				break;

			case "" + 8:
				primePoly_U = primePoly8_U;
				break;
			case "" + 9:
				primePoly_U = primePoly9_U;
				break;
			case "" + 10:
				primePoly_U = primePoly10_U;
				break;
				
				
			case "#" + posDefault:
				return -1;
			}

			xToW_U = 1 << power;
			GF_LOG = new short[xToW_U];
			GF_INVERSE_LOG = new short[xToW_U];


			b_U = 1;
			for(int log_U = 0; Integer.compareUnsigned(log_U, xToW_U - 1) < 0; log_U++) {
				GF_LOG[b_U] = (short)log_U;
				GF_INVERSE_LOG[log_U] = (short)b_U;
				b_U = b_U << 1;
				if((b_U & xToW_U) != 0) {
					b_U = b_U ^ primePoly_U;
				}
			}
			
			// FIX FOR POSITION OF 0 AND LAST NUMBER ..
			GF_LOG[0] = (short)(GF_LOG.length - 1);
			GF_INVERSE_LOG[GF_INVERSE_LOG.length-1] = (short)0;
			return 0;
		}		
	}

	/**
	 * FUNCTION TO RETURN THE VALUE OF THE GALOIS LOG TABLE
	 * @return LOG TABLE OF GALOS FIELD
	 */
	public short[] getGF_LOG() {
		return GF_LOG;
	}

	/**
	 * FUNCTION TO RETURN THE VALUE OF THE INVERSE GALOIS LOG TABLE
	 * @return LOG TABLE OF INVERSE GALOS FIELD
	 */	
	public short[] getGF_INVERSE_LOG() {
		return GF_INVERSE_LOG;
	}

}
