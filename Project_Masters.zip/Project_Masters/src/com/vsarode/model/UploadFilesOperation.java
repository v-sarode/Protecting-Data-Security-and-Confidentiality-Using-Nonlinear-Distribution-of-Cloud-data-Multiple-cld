package com.vsarode.model;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.dropbox.core.DbxException;

public class UploadFilesOperation {

	
	/**
	 * FUNCTION TO UPLOAD THE FILES TO THE CLOUDS
	 * @param C2FMap
	 * @throws DbxException
	 * @throws IOException
	 */
	public static void uploadAll(HashMap<String,String> C2FMap) throws DbxException, IOException{
		Properties prop = BucketConfigurations.getConfigObj();
		
		String cloud1 = prop.getProperty("CLOUD_1");
		String cloud2 = prop.getProperty("CLOUD_2");
		String cloud3 = prop.getProperty("CLOUD_3");
		String cloud4 = prop.getProperty("CLOUD_4");

		UploadThreads service1;
		UploadThreads service2;
		UploadThreads service3;
		UploadThreads service4;

		//	*/ if want to stop uploading uncomment 
		
		Thread t1 = null ,t2 = null,t3=null,t4=null;
		
		for (Map.Entry<String, String> entry : C2FMap.entrySet())
		{
			int bucketNumber = Character.getNumericValue(entry.getKey().charAt(entry.getKey().length()-1));
			switch (bucketNumber) {
			case 1:
				service1 = new UploadThreads(cloud1.substring(0, cloud1.indexOf("-")).trim(), 
											 cloud1.substring(cloud1.indexOf("-")+1,cloud1.length()).trim(), 
											new File(entry.getValue()));
				t1 = new Thread(service1);
				t1.start();
				break;
			case 2:
				service2 = new UploadThreads(cloud2.substring(0, cloud2.indexOf("-")).trim(), 
						 					 cloud2.substring(cloud2.indexOf("-")+1,cloud2.length()).trim(), 
						 					 new File(entry.getValue()));
				t2 = new Thread(service2);
				t2.start();
				
				break;
			case 3:
				service3 = new UploadThreads(cloud3.substring(0, cloud3.indexOf("-")).trim(), 
											cloud3.substring(cloud3.indexOf("-")+1,cloud3.length()).trim(), 
											new File(entry.getValue()));
				t3 = new Thread(service3);
				t3.start();
				
				break;
			case 4:	
				service4 = new UploadThreads(cloud4.substring(0, cloud4.indexOf("-")).trim(), 
											cloud4.substring(cloud4.indexOf("-")+1,cloud4.length()).trim(), 
											new File(entry.getValue()));
				t4 = new Thread(service4);
				t4.start();
				
				break;

			default:
				break;
			}
		}
	
		try {
			t1.join();
			t2.join();
			t3.join();
			t4.join();
		} catch (InterruptedException e) {
			JOptionPane.showMessageDialog(null, "Error Uploading Files Class: Upload File opearations. Please troubleshoot.. ");
			e.printStackTrace();
		}
	//	*/ if want to stop uploading 
	}
	
}
