package com.vsarode.model;

import java.util.ArrayList;
import java.util.Collections;

public class BucketFile {

	String FileNameInBucket;
	String[] Parameters;
	
	/**
	 * CONSTRUCTOR 
	 * @param FileNameInBucket ACTUAL FILENAME FROM CLOUD BUCKET
	 */
	public BucketFile(String FileNameInBucket) {
		this.FileNameInBucket = FileNameInBucket;
		this.Parameters = FileNameInBucket.split("_");
	}
	
	
	/**
	 * FUNCTION TO GET TOTAL NUMBER OF FILES DISTRIBUTED IN BUCKETS...
	 * @return NUMBER OF FRAGMENTS
	 */
	public int getTotalFragments(){
		return Character.getNumericValue(Parameters[1].charAt(Parameters[1].length()-1));
	}
	
	/**
	 * FUNCTION TO GET SEQUENCE IN WHICH FILES GOT STORED INTO THE CLOUD
	 * @return STRING SEQUENCE STRING
	 */
	public String getSequenceString(){
		return Parameters[2];
	}
	
	/**
	 * FUNCTION TO GET THE EXTENSION OF THE FILE.
	 * @return STRING EXTENSION
	 */
	public String getFileExtension(){
		return Parameters[4].substring(Parameters[4].lastIndexOf(".")+1, Parameters[4].length());
	}
	
	/**
	 * FUNCTION TO GET THE NAME OF FILE FIRST PART WITHOUT ANY DETAILS..
	 * @return NAME PART OF FILE
	 */
	public String getFileFirstName(){
		return Parameters[0];
	}
	
	/**
	 * FUNCTION TO GENERATE THE TOTAL FILENAME WITH EXTENSION.
	 * @return FILENAME WITH EXTENSION
	 */
	public String getFileName(){
		return this.getFileFirstName()+"."+this.getFileExtension();		
	}
	
	/**
	 * FUNCTION TO EXTRACT NUMBER OF FRAGMENT I.E. BUCKET FILENUMBER
	 * @return NUMBER OF BUCKET FILE UPLOADED TO
	 */
	public int getBucketNo(){
		return Character.getNumericValue((Parameters[4].charAt(0)));
	}
	
	
	/**
	 * FUNCTION TO GET NAME STRING BEFORE THE EXTENSION PART ..
	 * @return STRING BEFORE THE EXTENSION PART
	 */
	public String getPreExtensionNamePart(){
		return FileNameInBucket.substring(0, FileNameInBucket.lastIndexOf("."));
	}
	
	@Override
	public String toString() {
		return this.FileNameInBucket;
	}
	
	
	/**
	 * Generates an array of bucketSequence for downloading purpose..
	 * @return
	 */
	public int[] getSequenceArray(){
		
		ArrayList<Integer> in = new ArrayList<Integer>();
		char[] seq = this.getSequenceString().replaceAll("SQ", "").toCharArray();
		for (char c : seq) {
			in.add(Character.getNumericValue(c)); 
		}
		int[] bucketSequenceArray = new int[in.size()];
	    for (int i=0; i < bucketSequenceArray.length; i++)
	    {
	    	bucketSequenceArray[i] = in.get(i).intValue();
	    }

		return bucketSequenceArray;
	}
}
