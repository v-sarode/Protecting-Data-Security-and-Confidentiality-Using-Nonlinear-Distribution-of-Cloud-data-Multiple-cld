package com.vsarode.model;

public class DbxAppValues {
	// FINAL VALUES OF THE DROPBOX APPLICATION 
	private final static String DROP_BOX_APP_KEY = "7ox0onfwzh6byge" ;  
	private final static String DROP_BOX_APP_SECRET  = "qaw5ti8sg6d7ywk";
	
	/**
	 * FUNCTION FOR DROPBOX KEY OF THE APPLICATION 
	 * @return DROPBOX APPLICATION KEY
	 */
	public static String getDROP_BOX_APP_KEY() {
		return DROP_BOX_APP_KEY;
	}
	
	
	/**
	 * FUNCTION FOR DROPBOX APP SECRET OF THE APPLICATION 
	 * @return DROPBOX APPLICATION APP SECRET 
	 */	
	public static String getDROP_BOX_APP_SECRET() {
		return  DROP_BOX_APP_SECRET;
	}
}
