package com.vsarode.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.swing.JOptionPane;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxAuthFinish;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxWebAuthNoRedirect;
import com.dropbox.core.InvalidAccessTokenException;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.Metadata;

public class DownloadFileListGenerator {

	
	/**
	 * FUNCTION TO GET LIST OF FILES FROM THE AMAZON BUCKET...
	 * @param BucketName
	 * @return
	 */
	public static List<BucketFile> getAmazonFileList(String BucketName){
		List<BucketFile> fileList = new ArrayList<BucketFile>();
		AmazonS3 s3 = new AmazonS3Client();
		ObjectListing listing = s3.listObjects(BucketName);
		List<S3ObjectSummary> summaries = listing.getObjectSummaries();
		
		while (listing.isTruncated()) {
		   listing = s3.listNextBatchOfObjects (listing);
		   summaries.addAll (listing.getObjectSummaries());
		}
		for (S3ObjectSummary s3ObjectSummary : summaries) {
			if(s3ObjectSummary.getKey().indexOf("_") != -1){
				fileList.add(new BucketFile(s3ObjectSummary.getKey()));
			}
		}
		return fileList;
	}
	
	
	/**
	 * FUNCTION TO GET LIST OF FILES FORM THE DROPBOX BUCKET...
	 * @param BucketName
	 * @return
	 */
	public static List<BucketFile> getDbxFileList(String BucketName){
		List<BucketFile> fileList = new ArrayList<BucketFile>();

		
		
		Properties prop = BucketConfigurations.getConfigObj();
		String ACCESS_TOKEN  = prop.getProperty("ACCESS_TOKEN");
		DbxClientV2 _client = null;
		DbxRequestConfig requestConfig = new DbxRequestConfig("Cloud Data Distribution App /0.1", "");
		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		
		if(ACCESS_TOKEN.length()>50){
			_client = new DbxClientV2(requestConfig, ACCESS_TOKEN);
		}else{
			try {
				authFinish = webAuth.finish(ACCESS_TOKEN);
				_client = new DbxClientV2(requestConfig, authFinish.getAccessToken());
			}catch(InvalidAccessTokenException e){
				//  JOptionPane.showMessageDialog(null, "Error Downloading File list from Dropbox service. Please troubleshoot.. ");
				//	System.out.println("INVALID DROPBOX KEY FOUND.. ");
				// 	e.printStackTrace(); 				
			}catch (DbxException e1) {
				// JOptionPane.showMessageDialog(null, "Error DOwnloading file list from Dropbox service. Please troubleshoot.. ");
				//e1.printStackTrace();
			}			
		}
		try {
			List<Metadata> data= _client.files().listFolder("/"+BucketName).getEntries();
			for (Metadata metadata : data) {
				String filename = metadata.getName();
				fileList.add(new BucketFile(filename));
			}
		} catch (DbxException e) {
			e.printStackTrace();
		}		
		
		return fileList;
	}
	
	/**
	 * FUNCTION TO COBINE MULTIPLE FILE LISTS FROM N BUCKETS ...
	 * @return
	 */
 	public static List<BucketFile> downloadBucketFileList(){
		final List<BucketFile> list = new ArrayList<BucketFile>();
		List<String> l1 = null;
		
		Properties prop = BucketConfigurations.getConfigObj();
		
		String cloud1 = prop.getProperty("CLOUD_1");
		String cloud2 = prop.getProperty("CLOUD_2");
		String cloud3 = prop.getProperty("CLOUD_3");
		String cloud4 = prop.getProperty("CLOUD_4");

		final String cloud_1 = cloud1.substring(0, cloud1.indexOf("-")).trim();
		final String cloud_2 = cloud2.substring(0, cloud2.indexOf("-")).trim();
		final String cloud_3 = cloud3.substring(0, cloud3.indexOf("-")).trim();
		final String cloud_4 = cloud4.substring(0, cloud4.indexOf("-")).trim();

		Thread t1 = new Thread(new Runnable() {			
			@Override
			public void run() {
				list.addAll(getAmazonFileList(cloud_1));				
			}
		});
		t1.start();
		
		Thread t2 = new Thread(new Runnable() {			
			@Override
			public void run() {
				list.addAll(getAmazonFileList(cloud_2));				
			}
		});
		
		t2.start();
		
		Thread t3 = new Thread(new Runnable() {			
			@Override
			public void run() {
				list.addAll(getAmazonFileList(cloud_3));				
			}
		});
		t3.start();
		
		Thread t4 = new Thread(new Runnable() {			
			@Override
			public void run() {
				list.addAll(getDbxFileList(cloud_4));
			}
		});
		t4.start();
		
		try {
			t1.join();
			t2.join();
			t3.join();
			t4.join();
		} catch (InterruptedException e) {
			JOptionPane.showMessageDialog(null, "Error Downloading All Files From Dropbox Class: DownloadFileListGenerator. Please troubleshoot.. ");
			e.printStackTrace();
		}
		
		return list;
	}

 	
 	/**
 	 * FUNCTION TO GET LIST OF FILES 
 	 * @return SET CONTAINING FILENAMES AS STRING
 	 */
 	public static Set<String> getFileList(){
 		Set<String> set = new LinkedHashSet<String>();
 		List<BucketFile> allFilesList =  downloadBucketFileList(); 		
 		for (Iterator iterator = allFilesList.iterator(); iterator.hasNext();) {
			BucketFile bucketFile = (BucketFile) iterator.next();
			set.add(bucketFile.getFileName());
		} 		
 		return set;
 	}
 	
 	/**
 	 * FUNCTION TO GET LIST OF FILES IN BUCKET
 	 * @return LIST CONTAINING FILENAMES AS STRING
 	 */
 	public static List<BucketFile> getAllFilesInBuckets(){
 		List<BucketFile> CompleListOfFiles =  downloadBucketFileList();
 		List<BucketFile> allFilesList = new ArrayList<BucketFile>();
 		
 		for (Iterator iterator = CompleListOfFiles.iterator(); iterator.hasNext();) {
			BucketFile bucketFile = (BucketFile) iterator.next();
			allFilesList.add(bucketFile);
		}
 		return allFilesList;
 	}
 	
 	
 	/**
 	 * FUNCTION TO GENERATE THE LIST FOR ALL THE FILES IN ALL THE BUCKETS AND A SET TO VIEW IN GUI
 	 * @return OBJECT CONTAINING SET AND LIST BOTH..
 	 */
 	public static BucketFilesListHolder getFilesList(){

 		BucketFilesListHolder bucketFilesList = new BucketFilesListHolder();
 	 	Set<String> set = new LinkedHashSet<String>(); 		
 		List<BucketFile> CompleListOfFiles =  downloadBucketFileList();
 		List<BucketFile> allFilesList = new ArrayList<BucketFile>();
 		
 		for (Iterator iterator = CompleListOfFiles.iterator(); iterator.hasNext();) {
			BucketFile bucketFile = (BucketFile) iterator.next();
			set.add(bucketFile.getFileName());
			allFilesList.add(bucketFile);
		} 		
 		
 		bucketFilesList.setFilesList(allFilesList);
 		bucketFilesList.setFilesSet(set);
 		
 		return bucketFilesList;
 	}
 	
}
