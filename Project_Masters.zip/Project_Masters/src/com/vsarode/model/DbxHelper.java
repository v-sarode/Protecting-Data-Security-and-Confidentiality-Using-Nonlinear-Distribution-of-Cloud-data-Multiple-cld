package com.vsarode.model;

import java.util.List;
import java.util.Properties;

import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxAuthFinish;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxWebAuthNoRedirect;
import com.dropbox.core.InvalidAccessTokenException;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.Metadata;

public class DbxHelper {

	
	
	/**
	 * GET DBX CLIENT 
	 * @return DbxClientV2 client instance..
	 */
	public static DbxClientV2 getDbxClient(){
		Properties prop = BucketConfigurations.getConfigObj();
		final String ACCESS_TOKEN  = prop.getProperty("ACCESS_TOKEN");
		
		DbxClientV2 client = null;
		DbxRequestConfig requestConfig = new DbxRequestConfig("Cloud Data Distribution App /1.0.0", "");
		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		if(ACCESS_TOKEN.length() > 50){
			client = new DbxClientV2(requestConfig, ACCESS_TOKEN);
		}else{
			try {
				authFinish = webAuth.finish(ACCESS_TOKEN);
				client = new DbxClientV2(requestConfig, authFinish.getAccessToken());
			}catch(InvalidAccessTokenException e){
				System.out.println("Token invalid ");
			}catch (DbxException e) {
				e.printStackTrace();
			}			
		}		
		return client;
	}
	
	
	
	/**
	 * FUNCTION TO CHECK DROPBOX KEY IS VALID OR NOT..
	 * @return TRUE/FALSE
	 */
	public static boolean isKeyValid(){

		Properties prop = BucketConfigurations.getConfigObj();
		String ACCESS_TOKEN  = prop.getProperty("ACCESS_TOKEN");
//		final  DbxRequestConfig config = new DbxRequestConfig("testtest/1.0", "en_US");
		final DbxClientV2 _client;// = new DbxClientV2(config, ACCESS_TOKEN);
//---
		DbxRequestConfig requestConfig = new DbxRequestConfig("Cloud Data Distribution App /0.1", "");
		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		
		if(ACCESS_TOKEN.length()>50){
			_client = new DbxClientV2(requestConfig, ACCESS_TOKEN);
		}else{
			try {
				authFinish = webAuth.finish(ACCESS_TOKEN);
			}catch(InvalidAccessTokenException e){
				//	System.out.println("INVALID DROPBOX KEY FOUND.. ");
				return false;
			}catch (DbxException e1) {
				//e1.printStackTrace();
				return false;
			}			
			_client = new DbxClientV2(requestConfig, authFinish.getAccessToken());
		}
//---		
		try {			
			List<Metadata> data= _client.files().listFolder("").getEntries();
		} catch (InvalidAccessTokenException e) {
			//	System.out.println("INVALID DROPBOX KEY FOUND.. ");
			return false;
		}catch (DbxException e) {
		//	System.out.println("SOME ERROR IN DROPBOX KEY CHECK FUNCTION .. CLASS.Funciton() : DbxHelper.isKeyValid()");
		//	e.printStackTrace();
			return false;
		
		}			
		return true;
	}
}
