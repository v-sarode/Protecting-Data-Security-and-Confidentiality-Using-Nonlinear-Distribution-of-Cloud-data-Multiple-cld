package com.vsarode.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxAuthFinish;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxWebAuthNoRedirect;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.FileMetadata;

public class UploadThreads implements Runnable {

	private String cloud,service;
	File file;
	 static DefaultAWSCredentialsProviderChain credentialProviderChain = new DefaultAWSCredentialsProviderChain();
	
	
	/**
	 * CONSTRUCTOR
	 * @param cloud NAME OF THE BUCKET
	 * @param service NAME OF THE CLOUD SERVICE PROVIDER
	 * @param file NAME OF THE FILE TO BE UPLOADED ON THE CLOUD BUCKET.. 
	 */
	public UploadThreads(String cloud, String service, File file) {
		this.cloud = cloud;
		this.service = service;
		this.file = file;
	}

	
	@Override
	public void run() {
		uploadFileThread(file, cloud, service);
	}
	
	
	
	
	/**
	 * FUNCTION TO UPLOAD PARTICULAR FILE TO THE CORRSPONDING CLOUD SERVICE BUCKET 
	 * @param filename NAME OF THE FILE
	 * @param cloud NAME OF THE BUCKET
	 * @param service NAME OF THE CLOUD SERVICE PROVIDER
	 */
	public void uploadFileThread(File filename,String cloud,String service ){
		if(service.equalsIgnoreCase("amazon")){
			//this.uploadTOAmazon(new File(entry.getValue()),cloud1);
//			this.uploadTOAmazon(filename, cloud);
			this.uploadAmazonMultipart(file, cloud);
		}

		if(service.equalsIgnoreCase("dropbox")){
		//	this.uploadTODropbox((new File(entry.getValue())));
			this.uploadTODropbox(filename, cloud);
		}
		
	}
	

	/**
	 * DESC : UPLOAD FILE TO THE AMAZON S3 BUCKET 
	 * @param file FILE, BUCKET..
	 * @param BucketName NAME OF THE BUCKET
	 * @return TRUE/FLASE STATUS OF THE OPERATION 
	 */
	public boolean uploadTOAmazon(File file,String BucketName ){
		boolean status = false;
        AmazonS3 s3 = new AmazonS3Client();
        Region usWest2 = Region.getRegion(Regions.US_WEST_2);
        s3.setRegion(usWest2);
        
		String filename = file.getName();
        
		try {
			s3.putObject(new PutObjectRequest(BucketName, filename, file));
		} catch (AmazonServiceException e) {
			JOptionPane.showMessageDialog(null, "Error Uploading File On Amazon service. Please troubleshoot.. ");
			e.printStackTrace();
		} catch (AmazonClientException e) {
			JOptionPane.showMessageDialog(null, "Error Uploading File On Amazon service. Please troubleshoot.. ");
			e.printStackTrace();
		}
		
        status = true;
		return status;
	}
	

	/**
	 * FUNCTION TO UPLAOD THE FILE TO DROPBOX 
	 * @param file NAME OF THE FILE TO BE UPLOADED 
	 * @param BucketNam NAME OF THE BUCKET IN THE DROPBOX 
	 * @return TRUE/FALSE STATUS OF THE OPERATION
	 */
	public boolean uploadTODropbox(File file,String BucketName){
		
		Properties prop = BucketConfigurations.getConfigObj();
		String ACCESS_TOKEN = prop.getProperty("ACCESS_TOKEN");
		
		DbxClientV2 _client = null;
		
//		System.out.println("Access length :"+ACCESS_TOKEN.length());
//		System.out.println("Access token :"+ACCESS_TOKEN);
		
		boolean status = false;
		final  DbxRequestConfig config = new DbxRequestConfig("testtest/1.0", "en_US");
		DbxRequestConfig requestConfig = new DbxRequestConfig("text-edit/0.1", "");
		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		
		if(ACCESS_TOKEN.length()>50){
			_client = new DbxClientV2(config, ACCESS_TOKEN);
		}else{
			try {
				authFinish = webAuth.finish(ACCESS_TOKEN);
			} catch (DbxException e1) {
				e1.printStackTrace();
			}
			
			_client = new DbxClientV2(config, authFinish.getAccessToken());
		}

        
		String filename = file.getName();
		String uploadPath = "/"+BucketName+"/"+filename;
//		System.out.println(uploadPath);
	      try (InputStream in = new FileInputStream(file)) {
	          FileMetadata metadata = _client.files().uploadBuilder(uploadPath)
	              .uploadAndFinish(in);
	      } catch (DbxException | IOException e) {
	    	  JOptionPane.showMessageDialog(null, "Error Uploading File On Dropbox service. Please troubleshoot.. ");
	    	  System.out.println("Error in dbx upload thread");
			e.printStackTrace();
		}
		
        status = true;
		return status;
	}
	
	
	
	
	/**
	 * FUNCTION TO UPLOAD THE FILE TO AMAZON CLOUD USING MULTIPART FILE UPLAOD 
	 * WITH TRANSFER MANAGER ....
	 * @param myFile NAME OF THE FILE TO BE UPLOADED ON THE AMAZON BUCKET
	 * @param myBucket NAME OF THE AMAZON BUCKET
	 */
	public void uploadAmazonMultipart (File myFile,String myBucket ){
		synchronized (credentialProviderChain) {
		 TransferManager tx = new TransferManager(
	               credentialProviderChain.getCredentials());
		Upload myUpload = tx.upload(myBucket, myFile.getName(), myFile);
		try {
			myUpload.waitForCompletion();
		} catch (AmazonClientException | InterruptedException e) {
			JOptionPane.showMessageDialog(null, "Error Uploading File On Amazon service. Please troubleshoot.. ");
			System.out.println("some error in uploading threads ...");
			e.printStackTrace();
		}
		tx.shutdownNow();
		}	
	}
	

}
