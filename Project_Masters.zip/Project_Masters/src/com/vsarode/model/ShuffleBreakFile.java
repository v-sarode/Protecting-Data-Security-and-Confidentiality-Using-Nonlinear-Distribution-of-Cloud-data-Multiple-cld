package com.vsarode.model;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ShuffleBreakFile {

	// FINITE FILED LOG TABLE 
	private short[] GF_LOG;
	
	/**
	 * CONSTRUCTOR
	 * @param GF_LOG
	 */
	public ShuffleBreakFile(short[] GF_LOG) {
		this.GF_LOG = GF_LOG;
	}

	/**
	 * FUNCTION TO BREAK AND SHUFFLE FILE 
	 * @param filename ORIGINAL FILENAME
	 * @param filenames SUB FILE NAMES ...
	 * @param chunksize SIZE OF THE BUFFER
	 */
	public void startToBreakShuffleFile(String filename , String[] filenames, int chunksize ){
		File file = new File(filename);
		BufferedInputStream bis ;
		byte[] buffer = new byte[chunksize];
		File[] files = new File[filenames.length];
		FileOutputStream[] fos = new FileOutputStream[filenames.length];
		List<byte []> subBytes;
		
		for(int i = 0 ; i < filenames.length;i++){
			files[i] = new File(filenames[i]);
		}
		
		for (File subFile : files) {
			if(!subFile.exists()){
				try {
					subFile.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		for(int i = 0 ; i<filenames.length;i++){
			try {
				fos[i] = new FileOutputStream(files[i],true);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		
		try {
			bis = new BufferedInputStream(new FileInputStream(file));
			
			while(bis.read(buffer) > 0){
				byte[] newBuffer = scramble(buffer,GF_LOG);
				subBytes = this.divideArray(newBuffer, chunksize/filenames.length);

				int count = 0;
				for (byte[] bytechunk : subBytes) {
					fos[count].write(bytechunk);
					count++;
				}
				
			}
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	
	/**
	 * 
	 * @param buffer actual data in the buffer 
	 * @param scramble gflog table
	 */
	public  byte[]  scramble(byte[] buffer,short[] scramble){
		byte[] newBuffer = new byte[buffer.length];
		for(int i = 0 ; i<buffer.length ; i++){
			newBuffer[i] = buffer[scramble[i]];
		}
		return newBuffer;
	}
	
	/**
	 * DSCRIPTION : function splits buffer into the number of blocks
	 * @param buffer
	 * @param splitSize
	 */
	public List<byte[]> divideArray(byte[] source, int chunksize) {

	    List<byte[]> result = new ArrayList<byte[]>();
	    int start = 0;
	    while (start < source.length) {
	        int end = Math.min(source.length, start + chunksize);
	        result.add(Arrays.copyOfRange(source, start, end));
	        start += chunksize;
	    }

	    return result;
	}
	
	
}
