package com.vsarode.model;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxAuthFinish;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxWebAuthNoRedirect;
import com.dropbox.core.InvalidAccessTokenException;
import com.dropbox.core.v2.DbxClientV2;
//import com.dropbox.core;

public class DownloadFiles {

	
	/**
	 * FUNCTION TO DOWNLOAD FILES FROM CORRESTPONDING CLOUD BUCKETS ....
	 * @param C2FMap
	 * @param directory
	 * @throws IOException
	 */
	public void downloadAllFiles(HashMap<Integer,String> C2FMap,String directory) throws IOException{
		
		final String SEPARATOR = "/"; 
		Properties prop = BucketConfigurations.getConfigObj();
		
		String cloud1 = prop.getProperty("CLOUD_1");
		String cloud2 = prop.getProperty("CLOUD_2");
		String cloud3 = prop.getProperty("CLOUD_3");
		String cloud4 = prop.getProperty("CLOUD_4");
		for (Map.Entry<Integer, String> entry : C2FMap.entrySet())
		{
			
			switch (entry.getKey()) {
			
				case 1:
					String bucketName1 = cloud1.substring(0, cloud1.indexOf("-")).trim();
					String cloudSevice1 = cloud1.substring(cloud1.indexOf("-")+1,cloud1.length()).trim();
					 if(cloudSevice1.equalsIgnoreCase("amazon")){
						 this.downloadS3File(bucketName1, entry.getValue(), directory+File.separator+entry.getValue());
					 }else{
						try {
							this.downloadFromDropbox("/"+bucketName1+SEPARATOR+entry.getValue(), directory+SEPARATOR+entry.getValue());
						} catch (DbxException e) {
							JOptionPane.showMessageDialog(null, "Error Downloading File From Dropbox service. Please troubleshoot.. ");
							e.printStackTrace();
						}					 
					 }
					break;
					
					
				case 2:
					String bucketName2 = cloud2.substring(0, cloud2.indexOf("-")).trim();
					String cloudSevice2 = cloud2.substring(cloud2.indexOf("-")+1,cloud2.length()).trim();
					 if(cloudSevice2.equalsIgnoreCase("amazon")){
						 this.downloadS3File(bucketName2, entry.getValue(), directory+File.separator+entry.getValue());
					 }else{
						try {
							this.downloadFromDropbox("/"+bucketName2+SEPARATOR+entry.getValue(), directory+SEPARATOR+entry.getValue());
						} catch (DbxException e) {
							JOptionPane.showMessageDialog(null, "Error Downloading File From Dropbox service. Please troubleshoot.. ");
							e.printStackTrace();
						}					 
					 }
					break;
					
					
				case 3:
					String bucketName3 = cloud3.substring(0, cloud3.indexOf("-")).trim();
					String cloudSevice3 = cloud3.substring(cloud3.indexOf("-")+1,cloud3.length()).trim();
					 if(cloudSevice3.equalsIgnoreCase("amazon")){
						 this.downloadS3File(bucketName3, entry.getValue(), directory+File.separator+entry.getValue());
					 }else{
						try {
							this.downloadFromDropbox("/"+bucketName3+SEPARATOR+entry.getValue(), directory+SEPARATOR+entry.getValue());
						} catch (DbxException e) {
							JOptionPane.showMessageDialog(null, "Error Downloading File From Dropbox service. Please troubleshoot.. ");
							e.printStackTrace();
						}					 
					 }	
					break;
					
					
				case 4:
					String bucketName4 = cloud4.substring(0, cloud4.indexOf("-")).trim();
					String cloudSevice4 = cloud4.substring(cloud4.indexOf("-")+1,cloud4.length()).trim();
					 if(cloudSevice4.equalsIgnoreCase("amazon")){
						 this.downloadS3File(bucketName4, entry.getValue(), directory+File.separator+entry.getValue());					 
					 }else{
						try {
							this.downloadFromDropbox("/"+bucketName4+SEPARATOR+entry.getValue(), directory+SEPARATOR+entry.getValue());
						} catch (DbxException e) {
							JOptionPane.showMessageDialog(null, "Error Downloading File From Dropbox service. Please troubleshoot.. ");
							e.printStackTrace();
						}					 
					 }
					break;
					
				default:
					break;
			}
		}
	}

	
	
	
	
	/**
	 * DOWNLOAD FILE FROM THE DROPBOX BUCKET AS SPECIFIED 
	 * @param fileName
	 * @param outputFileName
	 * @throws DbxException
	 * @throws IOException
	 */
	public void downloadFromDropbox_test(String fileName,String outputFileName) throws DbxException,IOException {

		
		Properties prop = BucketConfigurations.getConfigObj();
		String ACCESS_TOKEN = prop.getProperty("ACCESS_TOKEN");
		
	      DbxRequestConfig config = new DbxRequestConfig("dropbox/Masteres-project-testing", "en_US");
	      DbxClientV2 _client = null;

		FileOutputStream outputStream = new FileOutputStream(outputFileName);
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		DbxRequestConfig requestConfig = new DbxRequestConfig("text-edit/0.1", "");
		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		
		if(ACCESS_TOKEN.length()>60){
			_client = new DbxClientV2(requestConfig, ACCESS_TOKEN);
		}else{
			try {
				System.out.println(ACCESS_TOKEN);
				authFinish = webAuth.finish(ACCESS_TOKEN);
				System.out.println(authFinish.getAccessToken());
				System.out.println(requestConfig);

			}catch(InvalidAccessTokenException e){
					System.out.println("INVALID DROPBOX KEY FOUND.. ");
					e.printStackTrace();
			//	return false;

			}catch (DbxException e1) {
				e1.printStackTrace();
			//	return false;
			}
			_client = new DbxClientV2(requestConfig, authFinish.getAccessToken());			
			System.out.println("access in 60- exit");
		}
		
		try {
			System.out.println("filename"+fileName);
			_client.files().download(fileName).download(bout);
			outputStream.write(bout.toByteArray());
		} finally {
		    outputStream.close();
		}		
	}
	

	/**
	 * FUNCTION TO CHECK IS FILE EXIST ON THE DROPBOX...
	 * @param filename
	 * @return TRUE/FALSE..
	 */
	public boolean isFileOnDbx(String filename){
		Properties prop = BucketConfigurations.getConfigObj();
		String ACCESS_TOKEN = prop.getProperty("ACCESS_TOKEN");
	//	DbxRequestConfig config = new DbxRequestConfig("dropbox/Masteres-project-testing", "en_US");
		DbxClientV2 client; //= new DbxClientV2(config, ACCESS_TOKEN);
		
		DbxRequestConfig requestConfig = new DbxRequestConfig("Cloud Data Distribution App /0.1", "");
		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		
		if(ACCESS_TOKEN.length()>50){
			client = new DbxClientV2(requestConfig, ACCESS_TOKEN);
		}else{
			try {
				authFinish = webAuth.finish(ACCESS_TOKEN);
			}catch(InvalidAccessTokenException e){
				System.out.println("INVALID DROPBOX KEY FOUND.. ");
				JOptionPane.showMessageDialog(null, "Error Invalid Dropbox Key. Please troubleshoot.. ");
			}catch (DbxException e1) {
				JOptionPane.showMessageDialog(null, "Error donwloading File from Dropbox service. Please troubleshoot.. ");
				e1.printStackTrace();
				//return false;
			}			
			client = new DbxClientV2(requestConfig, authFinish.getAccessToken());
		}
		
		try {
			client.files().download(filename);
		} catch (DbxException e) {	
			return false;
		}
		return true;
	}
	
	
	/**
	 * FUNCTION TO DOWNLOAD FILE FROM THE AMAZON S3 BUCKET TO THE LOCAL DISC
	 * @param bucketName NAME OF AMAZON S3 BUCKET
	 * @param key NAME OF THE FILE IN THE S3 BUCKET
	 * @param outputFileName NAME OF THE FILE ON THE LOCAL DISC AFTER DOWNLOAD
	 * @throws IOException 
	 */
	public void downloadS3File(String bucketName, String key, String outputFileName) throws IOException {		
		int BUFFER_SIZE = 1024;
		AmazonS3 s3 = new AmazonS3Client();
		
		S3Object s3object = null;
		
		try {
			s3object = s3.getObject(new GetObjectRequest(bucketName, key));
		} catch (AmazonClientException e) {
			JOptionPane.showMessageDialog(null, "Error Uploading File From Amazon service. Please troubleshoot.. ");
			e.printStackTrace();
		}
		
		InputStream stream = s3object.getObjectContent();
		byte[] content = new byte[BUFFER_SIZE];
		
		BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(outputFileName));
		int totalSize = 0;
		int bytesRead;
		while ((bytesRead = stream.read(content)) != -1) {
		  outputStream.write(content, 0, bytesRead);
		  totalSize += bytesRead;
		}
		outputStream.close();
	  }
	
	
	/**
	 * FUNCTION TO DOWNLOAD SPECIFIC FILE FROM THE DROPBOX BUCKET  
	 * @param fileName   DESC: Name of file from the bucket 
	 * @param outputFileName DESC: output filename
	 * @throws DbxException
	 * @throws IOException
	 */
	public void downloadFromDropbox(String fileName,String outputFileName) throws DbxException,IOException {
		Properties prop = BucketConfigurations.getConfigObj();
		String ACCESS_TOKEN = prop.getProperty("ACCESS_TOKEN");
		FileOutputStream outputStream = new FileOutputStream(outputFileName);
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		
		DbxClientV2 _client = null;
		
		boolean status = false;
		final  DbxRequestConfig config = new DbxRequestConfig("testtest/1.0", "en_US");
		DbxRequestConfig requestConfig = new DbxRequestConfig("text-edit/0.1", "");

		DbxAppInfo appInfo = new DbxAppInfo(DbxAppValues.getDROP_BOX_APP_KEY(), DbxAppValues.getDROP_BOX_APP_SECRET());
		
		DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(requestConfig, appInfo);
		DbxAuthFinish authFinish = null;

		
		if(ACCESS_TOKEN.length()>50){
			_client = new DbxClientV2(config, ACCESS_TOKEN);
		}else{
			try {
				authFinish = webAuth.finish(ACCESS_TOKEN);
			} catch (DbxException e1) {
				JOptionPane.showMessageDialog(null, "Error Accessing dropbox for downloading file Error : invalis access token. Please troubleshoot.. ");
				e1.printStackTrace();
			}
			
			_client = new DbxClientV2(config, authFinish.getAccessToken());
		}
	
		
		try {
			_client.files().download(fileName).download(bout);
			outputStream.write(bout.toByteArray());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error Downloading File From Dropbox service. Please troubleshoot.. ");
			e.printStackTrace();
		}finally {
			bout.close();
		    outputStream.close();
		}		
	
	}
	
}
