package com.vsarode.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class DownloadHelper {
	
	/**
	 * FUNCTION TO SORT THE FILES 
	 * @param completeFilesList
	 * @param targetFileName
	 * @return BUCKETFILE OBJECT..
	 */
	public static BucketFile SortFiles(List<BucketFile> completeFilesList, String targetFileName){
		BucketFile selectedFile = null;
		for (BucketFile bucketFile : completeFilesList) {
			if(bucketFile.getFileName().equalsIgnoreCase(targetFileName)){
				return bucketFile;
			}
		}
		return selectedFile;
	}
	
	/**
	 * FUNCTION CREATES NAMES LIST ARRAY TO DOWNLOAD FILES ON SPECIFIC TARGET DIRECTORY..
	 * @param selectedFile
	 * @return STRING ARRAY OF FILENAMES ON TARGET DIRECTORY..
	 */
	public static String[] createTargetFileList(BucketFile selectedFile){
		int[] sequenceArray = selectedFile.getSequenceArray();
		String[] FileList = new String[sequenceArray.length];
		String preFileName = selectedFile.getPreExtensionNamePart().substring(0, selectedFile.getPreExtensionNamePart().length()-1);
		String extension = "."+selectedFile.getFileExtension();

		int count = 0;
		for (int bucketNumber : sequenceArray) {
			FileList[count++] = preFileName+bucketNumber+extension;
		}
		
		return FileList;
	}
	
	
	/**
	 * FUNCTION TO CREATE A MAPPING WITH CLOUDS TO FILE IN A HASHMAP FOR DOWNLOADING PURPOSE.
	 * @param selectedFile
	 * @return HASHMAP OF INT AS KEY ANS STRING AS VALUE OF FILENAME...
	 */
	public static HashMap<Integer,String> getC2FMaping(BucketFile selectedFile){
		HashMap<Integer,String> C2FMap = new HashMap<Integer,String>();
		int[] bucketList =selectedFile.getSequenceArray();
		String preFileName = selectedFile.getPreExtensionNamePart().substring(0, selectedFile.getPreExtensionNamePart().length()-1);
		String extension = "."+selectedFile.getFileExtension();
		
		for (int i : bucketList) {
			String tempName = preFileName+i+extension;
			C2FMap.put(i, tempName);
		}
		
		return C2FMap;
	}
}
