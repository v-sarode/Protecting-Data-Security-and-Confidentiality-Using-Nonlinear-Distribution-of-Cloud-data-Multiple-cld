package com.vsarode.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class FileNameOperations {
	
	/**
	 * FUNCTION TO EXTRACT FILE NAME FROM THE GIVEN STRING SEPARATE FROM EXTENSION
	 * @param filePath
	 * @return Name of file 
	 */
	public static String getFileName(String filePath){
		if(filePath.indexOf(".") != -1){	
		//	replaceUnderscore(filePath)
			return replaceUnderscore(filePath.substring(0, filePath.indexOf(".")));
		}else{
			return replaceUnderscore(filePath);
		}
		//return filePath.substring(0, filePath.indexOf("."));		
	}
	
	
	/**
	 * FUNCTION TO EXTRACT EXTENSION FROM THE FILENAME GIVEN IN THE STRING..
	 * @param filePath
	 * @return EXTENSION IF PRESENT
	 */
	public static String getFileExtension(String filePath){
		if(filePath.indexOf(".") != -1){
			return filePath.substring(filePath.indexOf(".")+1, filePath.length());
		}else{
			return "";
		}
	}
	

	/**
	 * FUNCTION TO REPLACE THE UNDERSCORES(_) TO HYPHEN(-) IMP FOR APPLICATION TO REPLACE UNDERSCORES OF EXISTS 
	 * @param fileName
	 * @return STRING REPLACED WITH THE FILE NAME WITHOUD UNDERSCORES 
	 */
	public static String replaceUnderscore(String fileName){
		if(fileName.indexOf("_") != -1){
			return fileName.replace("_", "-");
		}else{
			return fileName;
		}
	}
	
	/**
	 * FUNCTION TO CREATE FILE NAMES FROM THE GIVEN FILENAME STRING AND LIST OF CLOUD BUCKETS..
	 * @param filename
	 * @param clouds
	 * @return LIST OF FILES NAMES WITH THE FILENAMES  
	 */
	public static List<String> createFileNames(String filename, HashSet<String> clouds){
		List<String> filenames = new ArrayList<String>();
//		System.out.println("filename in generation is : "+filename);
		String first = getFileName(filename);
		String ext = getFileExtension(filename);
		
		String suffix ="SQ";
		for (String cloud : clouds) {
			suffix += cloud.substring(cloud.length() - 1);	
		}
		
		String fileCount = "T"+clouds.size();
		for (String string : clouds) {
			String temp = "";
			if(ext != null){
				temp = first+"_"+fileCount+"_"+suffix+"_"+string+"."+ext;
			}else{
				temp = first+"_"+fileCount+"_"+suffix+"_"+string;
			}
			filenames.add(temp);
		}
		return filenames;
	}
	
	
	/**
	 * function to create the mapping from cloud to filenames 
	 * @param filename
	 * @param clouds
	 * @return
	 */
	public static HashMap<String,String> createC2FHashMap(String filename, HashSet<String> clouds){
		List<String> filenames = new ArrayList<String>();
		HashMap<String,String> C2FMap= new HashMap<String,String>();

		String first = getFileName(filename);
		String ext = getFileExtension(filename);
		
		String suffix ="SQ";
		for (String cloud : clouds) {
			suffix += cloud.substring(cloud.length() - 1);	
		}
		
		String fileCount = "T"+clouds.size();
		for (String string : clouds) {
			String temp = "";
			if(ext != null){
				temp = first+"_"+fileCount+"_"+suffix+"_"+string+"."+ext;
			}else{
				temp = first+"_"+fileCount+"_"+suffix+"_"+string;
			}
			C2FMap.put(string, temp);
		}
		return C2FMap;
	}
	
}
