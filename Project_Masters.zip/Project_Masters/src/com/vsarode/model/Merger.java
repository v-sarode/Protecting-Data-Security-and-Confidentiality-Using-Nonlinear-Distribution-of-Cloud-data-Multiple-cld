package com.vsarode.model;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Merger {
	
	/**
	 * FUNCTION TO MERGE FILES 2 FILES 
	 * @param fileList LIST OF FILES TO BE MERGED
	 * @param ouputfilename SINGLE OUTPUT FILE 
	 * @param tables FINITE FIELD OBJECT FOR GF AND INVERSE GF TABLE
	 * @param chunkSize BUFFFER SIZE FINITE FIELD SIZE
	 * @param directoryPath PATH WHERE FINAL FILE SHOULD BE PLACED..
	 */
	public void merge2Files(String[] fileList,String ouputfilename,FiniteField tables,int chunkSize,String directoryPath){
		final int TotalFiles = 2;
		short [] log = tables.getGF_LOG();
		short [] ilog = tables.getGF_INVERSE_LOG();
		String fileSeparator = File.separator;
		File file1 = new File(directoryPath+fileSeparator+fileList[0]);
		File file2 = new File(directoryPath+fileSeparator+fileList[1]);;
		File file_merged = new File(directoryPath+fileSeparator+ouputfilename);
	
		int subbuffersize = chunkSize/TotalFiles;
		
		byte[] readBuffer1 = new byte[subbuffersize];
		byte[] readBuffer2 = new byte[subbuffersize];
		FileOutputStream fos = null;
		
		BufferedInputStream bis1 = null;
		BufferedInputStream bis2 = null;
		try {
			
			if(!file_merged.exists()){
				try {
					 file_merged.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			fos = new FileOutputStream(file_merged,true);

			bis1 = new BufferedInputStream(new FileInputStream(file1));
			bis2 = new BufferedInputStream(new FileInputStream(file2));
			while(bis1.read(readBuffer1) > 0 && bis2.read(readBuffer2) > 0 ){

				ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
				outputStream.write( readBuffer1 );
				outputStream.write( readBuffer2 );
				
				byte c[] = outputStream.toByteArray( );				

				byte[] newBuffer = scramble1(c, log, ilog);
				fos.write(newBuffer);
			}			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				bis1.close();
				bis2.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		this.deleteFiles(file1,file2);
//		file1.delete();
//		file2.delete();
		
		
//	 System.out.println("File created ");
	}
	
	
	/**
	 * FUNCTION TO MERGE FILES 4 FILES 
	 * @param fileList LIST OF FILES TO BE MERGED
	 * @param ouputfilename SINGLE OUTPUT FILE 
	 * @param tables FINITE FIELD OBJECT FOR GF AND INVERSE GF TABLE
	 * @param chunkSize BUFFFER SIZE FINITE FIELD SIZE
	 * @param directoryPath PATH WHERE FINAL FILE SHOULD BE PLACED..
	 */	
	public void merge4Files(String[] fileList,String ouputfilename,FiniteField tables,int chunkSize,String directoryPath){
		final int TotalFiles = 4;
		short [] log = tables.getGF_LOG();
		short [] ilog = tables.getGF_INVERSE_LOG();
		
//		for (String s : fileList) {
//			System.out.println("filename : "+s);
//		}
//		System.out.println("Length of buffer is "+chunkSize);
//		System.out.println("Length of gf log is "+log.length);
//		System.out.println(" and inverse log is "+ilog.length);

		String fileSeparator = File.separator;
		
		File file1 = new File(directoryPath+fileSeparator+fileList[0]);
		File file2 = new File(directoryPath+fileSeparator+fileList[1]);;
		File file3 = new File(directoryPath+fileSeparator+fileList[2]);
		File file4 = new File(directoryPath+fileSeparator+fileList[3]);
		File file_merged = new File(directoryPath+fileSeparator+ouputfilename);
	
		int subbuffersize = chunkSize/TotalFiles;
		
		byte[] readBuffer1 = new byte[subbuffersize];
		byte[] readBuffer2 = new byte[subbuffersize];
		byte[] readBuffer3 = new byte[subbuffersize];
		byte[] readBuffer4 = new byte[subbuffersize];
		FileOutputStream fos = null;
		
		BufferedInputStream bis1 = null;
		BufferedInputStream bis2 = null;
		BufferedInputStream bis3 = null;
		BufferedInputStream bis4 = null;
		try {
			
			if(!file_merged.exists()){
				try {
					 file_merged.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			fos = new FileOutputStream(file_merged,true);

			bis1 = new BufferedInputStream(new FileInputStream(file1));
			bis2 = new BufferedInputStream(new FileInputStream(file2));
			bis3 = new BufferedInputStream(new FileInputStream(file3));
			bis4 = new BufferedInputStream(new FileInputStream(file4));
			while(bis1.read(readBuffer1) > 0 && bis2.read(readBuffer2) > 0 && bis3.read(readBuffer3) > 0 && bis4.read(readBuffer4) > 0){

				ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
				outputStream.write( readBuffer1 );
				outputStream.write( readBuffer2 );
				outputStream.write( readBuffer3 );
				outputStream.write( readBuffer4 );
				
				byte c[] = outputStream.toByteArray( );				

				byte[] newBuffer = scramble1(c, log, ilog);
				fos.write(newBuffer);
			}			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				bis1.close();				
				bis2.close();
				bis3.close();
				bis4.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		this.deleteFiles(file1,file2,file3,file4);
//		file1.delete();
//		file2.delete();
//		file3.delete();
//		file4.delete();
//	 System.out.println("File created ");
		
	}
	
	/**
	 * FUNCTION TO DELETE NUMBER OF TOTAL SUPPLIES FILES 
	 * @param files
	 * @return
	 */
	public boolean deleteFiles(File... files) {
		boolean result = false;
		for (File file : files) {
			result  = file.delete();
		}		
		return result;
	}
	
	/**
	 * 
	 * @param buffer actual data in the buffer
	 * @param log gflog table
	 * @param ilog gfilog table 
	 */
	public  byte[]  scramble1(byte[] buffer,short[] log,short[] ilog){
	//	byte temp;
		byte[] newBuffer = new byte[buffer.length];
		for(int i = 0 ; i<buffer.length ; i++){
			newBuffer[i] = buffer[ilog[i]];
		}
		return newBuffer;
	}
	
	
}
