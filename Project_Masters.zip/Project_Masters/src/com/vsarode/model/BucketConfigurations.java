package com.vsarode.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import com.vsarode.gui.CloudServicesOptions;

public class BucketConfigurations {
	
	// FILE PATH FOR SETTINGS
	final static String SETTINGS_FILE_PATH  = "settings.properties";
	
	
	/**
	 * FUNCTION TO CHECK WHETHER BUCKET SETTING IS CONFIGURED OR NOT
	 * @return TRUE/FALSE
	 */
	public static boolean isBucketConfigured(){
			
		File settingsFile = new File(SETTINGS_FILE_PATH);
		if(settingsFile.exists() && !settingsFile.isDirectory()) { 
			return true;
		}
		
		return false;
	}
	
	

	/**
	 * DESC: FUNCTION TO GET THE PROPERTIES OF THE APPLICATION...
	 * @return PROPERTIES OBJECT OF FILE HANDLE
	 */
	public static Properties getConfigObj(){
		Properties prop = new Properties();
		InputStream input = null;
	//	String FileName = "App.properties";
		File f = new File(SETTINGS_FILE_PATH);
		if(f.exists()){
			try {
				input = new FileInputStream(SETTINGS_FILE_PATH);
				prop.load(input);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			prop = null;
		}
		return prop;
	}
	
	
	/**
	 * DESC: FUNCTION TO SAVE THE PROPERTIES OF THE APPLICATION
	 */
	public static boolean saveAppProperties(	String dbxKey,
											String bucket1,
											String bucket2,
											String bucket3,
											String bucket4,
											CloudServicesOptions b1cloud,
											CloudServicesOptions b2cloud,
											CloudServicesOptions b3cloud,
											CloudServicesOptions b4cloud
										
										) {
	    try {            
	        String DBX_APP_KEY = dbxKey;
	        String CLOUD_1 = bucket1+"-"+b1cloud.getCloudName();
	        String CLOUD_2 = bucket2+"-"+b2cloud.getCloudName();
	        String CLOUD_3 = bucket3+"-"+b3cloud.getCloudName();
	        String CLOUD_4 = bucket4+"-"+b4cloud.getCloudName();
	        
	        //create a properties file
	        Properties props = new Properties();
	        props.setProperty("ACCESS_TOKEN", DBX_APP_KEY);
	        props.setProperty("CLOUD_1", CLOUD_1);
	        props.setProperty("CLOUD_2", CLOUD_2);
	        props.setProperty("CLOUD_3", CLOUD_3);
	        props.setProperty("CLOUD_4", CLOUD_4);
	        File f = new File(SETTINGS_FILE_PATH);
	        OutputStream out = new FileOutputStream( f );
	        
	        if(!f.exists()){
				try {
					f.createNewFile();
				} catch (IOException e) {
					
					e.printStackTrace();
					return false;
				}
			}
	        //If you wish to make some comments 
	        props.store(out, "Application properties");
	    }
	    catch (Exception e ) {
	        e.printStackTrace();
	        return false;
	    }
	return true;
	}
	
	
	
	/**
	 * FUNCTION TO SET NEW DROPBOX KEY INTO THE SETTINGS FILE 
	 * @param dbxKey
	 * @return TRUE/FALSE..
	 */
	public static boolean setNewDbxKey(String dbxKey){
		Properties property = getConfigObj();
		File f = null;
		OutputStream out = null;
		try {
			property.setProperty("ACCESS_TOKEN", dbxKey);
	        f = new File(SETTINGS_FILE_PATH);
	        out = new FileOutputStream( f );
	        
	        if(!f.exists()){
				try {
					f.createNewFile();
				} catch (IOException e) {
					
					e.printStackTrace();
					return false;
				}
			}
	        //If you wish to make some comments 
	        property.store(out, "Application properties");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Some error updating dropbox key..");			
			//e.printStackTrace();
			return false;
		}finally{
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
}
